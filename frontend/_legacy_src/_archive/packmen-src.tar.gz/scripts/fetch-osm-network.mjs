#!/usr/bin/env node
/**
 * Build the operational road network from OpenStreetMap.
 *
 *   node scripts/fetch-osm-network.mjs
 *
 * Downloads the drivable road network for a bounding box (central Ghaziabad by
 * default), reduces it to a junction graph with real road geometry, snaps
 * hospitals and fire stations onto it, and writes src/data/network.json.
 *
 * Run it once. After that the app is fully offline — nothing queries Overpass at
 * runtime, so a flaky network on demo day cannot break the map.
 *
 * Requires Node 18+ (uses global fetch). No npm dependencies.
 *
 * Options:
 *   --bbox=S,W,N,E        override the area
 *   --name="..."          label stored in the file
 *   --residential         include residential streets (denser, slower)
 *   --max-nodes=N         thin the graph if it exceeds N junctions (default 900)
 *   --out=path            output file (default src/data/network.json)
 *   --endpoint=url        alternate Overpass instance
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PROJECT = path.resolve(__dirname, '..');

/* ------------------------------------------------------------------ options */

const args = Object.fromEntries(
  process.argv.slice(2).map((a) => {
    const [k, ...v] = a.replace(/^--/, '').split('=');
    return [k, v.length ? v.join('=') : true];
  }),
);

/** Central Ghaziabad: Raj Nagar, Kavi Nagar, Nehru Nagar, GT Road, Mohan Nagar. */
const DEFAULT_BBOX = [28.63, 77.38, 28.71, 77.47]; // south, west, north, east

const BBOX = args.bbox ? args.bbox.split(',').map(Number) : DEFAULT_BBOX;
const AREA_NAME = args.name || 'Central Ghaziabad, Uttar Pradesh';
const MAX_NODES = Number(args['max-nodes'] || 900);
const OUT = path.resolve(PROJECT, args.out || 'src/data/network.json');
const ENDPOINT = args.endpoint || 'https://overpass-api.de/api/interpreter';

const ROAD_CLASSES = [
  'motorway',
  'trunk',
  'primary',
  'secondary',
  'tertiary',
  'unclassified',
  'motorway_link',
  'trunk_link',
  'primary_link',
  'secondary_link',
  'tertiary_link',
];
if (args.residential) ROAD_CLASSES.push('residential', 'living_street');

/** Rank used when the graph has to be thinned — higher survives. */
const CLASS_RANK = {
  motorway: 9,
  trunk: 8,
  primary: 7,
  secondary: 6,
  tertiary: 5,
  unclassified: 3,
  residential: 2,
  living_street: 1,
};
const rankOf = (cls) => CLASS_RANK[String(cls).replace(/_link$/, '')] ?? 2;

/* ---------------------------------------------------------------- geometry */

const R = 6371000;
const toRad = (d) => (d * Math.PI) / 180;

function haversine(a, b) {
  const dLat = toRad(b[0] - a[0]);
  const dLng = toRad(b[1] - a[1]);
  const h =
    Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a[0])) * Math.cos(toRad(b[0])) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

const polylineLength = (coords) => {
  let total = 0;
  for (let i = 1; i < coords.length; i += 1) total += haversine(coords[i - 1], coords[i]);
  return total;
};

const round = (n, dp = 6) => Number(n.toFixed(dp));

/* ---------------------------------------------------------------- overpass */

async function overpass(query) {
  const res = await fetch(ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ data: query }).toString(),
  });
  if (!res.ok) {
    throw new Error(`Overpass returned ${res.status} ${res.statusText}. Try again in a minute, or pass --endpoint=`);
  }
  return res.json();
}

const [S, W, N, E] = BBOX;
const bboxStr = `${S},${W},${N},${E}`;

const ROAD_QUERY = `
[out:json][timeout:180];
way[highway~"^(${ROAD_CLASSES.join('|')})$"](${bboxStr});
out geom;
`;

const PLACE_QUERY = `
[out:json][timeout:120];
(
  node[amenity~"^(hospital|clinic|fire_station)$"](${bboxStr});
  way[amenity~"^(hospital|clinic|fire_station)$"](${bboxStr});
  relation[amenity~"^(hospital|clinic|fire_station)$"](${bboxStr});
);
out center tags;
`;

/* ------------------------------------------------------------ graph build */

function buildGraph(ways) {
  // A junction is any OSM node shared by two or more ways, plus every way end.
  const useCount = new Map();
  for (const way of ways) {
    if (!way.nodes || !way.geometry) continue;
    way.nodes.forEach((id, i) => {
      const bump = i === 0 || i === way.nodes.length - 1 ? 2 : 1;
      useCount.set(id, (useCount.get(id) || 0) + bump);
    });
  }

  const isJunction = (id) => (useCount.get(id) || 0) >= 2;

  const nodes = new Map(); // osmId -> { lat, lng, roads:Set }
  const edges = [];

  for (const way of ways) {
    if (!way.nodes || !way.geometry || way.nodes.length < 2) continue;
    const roadName = way.tags?.name || null;
    const roadClass = way.tags?.highway || 'unclassified';

    let startIdx = 0;
    for (let i = 1; i < way.nodes.length; i += 1) {
      const last = i === way.nodes.length - 1;
      if (!isJunction(way.nodes[i]) && !last) continue;

      const fromId = way.nodes[startIdx];
      const toId = way.nodes[i];
      if (fromId === toId) {
        startIdx = i;
        continue;
      }

      const geometry = way.geometry.slice(startIdx, i + 1).map((p) => [round(p.lat), round(p.lon)]);
      if (geometry.length < 2) {
        startIdx = i;
        continue;
      }

      for (const [osmId, idx] of [
        [fromId, startIdx],
        [toId, i],
      ]) {
        if (!nodes.has(osmId)) {
          nodes.set(osmId, {
            lat: round(way.geometry[idx].lat),
            lng: round(way.geometry[idx].lon),
            roads: new Set(),
          });
        }
        if (roadName) nodes.get(osmId).roads.add(roadName);
      }

      edges.push({
        from: fromId,
        to: toId,
        geometry,
        length: Math.round(polylineLength(geometry)),
        roadName,
        roadClass,
      });

      startIdx = i;
    }
  }

  return { nodes, edges };
}

/** Collapse pass-through junctions (degree 2) into a single longer edge. */
function simplifyDegreeTwo(nodes, edges, protectedIds) {
  const adjacency = new Map();
  const alive = new Set(edges.keys ? [] : []);
  const edgeList = edges.map((e, i) => ({ ...e, id: i, dead: false }));

  for (const e of edgeList) {
    if (!adjacency.has(e.from)) adjacency.set(e.from, []);
    if (!adjacency.has(e.to)) adjacency.set(e.to, []);
    adjacency.get(e.from).push(e);
    adjacency.get(e.to).push(e);
  }

  let merged = 0;
  for (const [nodeId, incident] of adjacency) {
    if (protectedIds.has(nodeId)) continue;
    const live = incident.filter((e) => !e.dead);
    if (live.length !== 2) continue;

    const [a, b] = live;
    if (a.from === a.to || b.from === b.to) continue;
    const otherA = a.from === nodeId ? a.to : a.from;
    const otherB = b.from === nodeId ? b.to : b.from;
    if (otherA === otherB) continue; // would create a self-loop

    const geomA = a.from === nodeId ? a.geometry.slice().reverse() : a.geometry.slice();
    const geomB = b.from === nodeId ? b.geometry.slice() : b.geometry.slice().reverse();
    const geometry = [...geomA, ...geomB.slice(1)];

    a.dead = true;
    b.dead = true;
    const combined = {
      id: edgeList.length,
      from: otherA,
      to: otherB,
      geometry,
      length: Math.round(polylineLength(geometry)),
      roadName: a.roadName || b.roadName,
      roadClass: rankOf(a.roadClass) >= rankOf(b.roadClass) ? a.roadClass : b.roadClass,
      dead: false,
    };
    edgeList.push(combined);
    adjacency.get(otherA).push(combined);
    adjacency.get(otherB).push(combined);
    nodes.delete(nodeId);
    merged += 1;
  }

  void alive;
  return { edges: edgeList.filter((e) => !e.dead), merged };
}

function largestComponent(nodes, edges) {
  const adjacency = new Map();
  for (const e of edges) {
    if (!adjacency.has(e.from)) adjacency.set(e.from, []);
    if (!adjacency.has(e.to)) adjacency.set(e.to, []);
    adjacency.get(e.from).push(e.to);
    adjacency.get(e.to).push(e.from);
  }

  const seen = new Set();
  let best = new Set();
  for (const start of adjacency.keys()) {
    if (seen.has(start)) continue;
    const component = new Set([start]);
    const stack = [start];
    seen.add(start);
    while (stack.length) {
      const cur = stack.pop();
      for (const nxt of adjacency.get(cur) || []) {
        if (seen.has(nxt)) continue;
        seen.add(nxt);
        component.add(nxt);
        stack.push(nxt);
      }
    }
    if (component.size > best.size) best = component;
  }

  return {
    nodes: new Map([...nodes].filter(([id]) => best.has(id))),
    edges: edges.filter((e) => best.has(e.from) && best.has(e.to)),
  };
}

/* ----------------------------------------------------------------- naming */

function nameJunction(node, edges, index) {
  const roads = [...new Set(edges.filter((e) => e.roadName).map((e) => e.roadName))];
  if (roads.length >= 2) return `${roads[0]} / ${roads[1]}`;
  if (roads.length === 1) return `${roads[0]} junction`;
  const fromNode = [...(node.roads || [])];
  if (fromNode.length) return `${fromNode[0]} junction`;
  return `Junction ${index}`;
}

/* --------------------------------------------------------------- main run */

async function main() {
  console.log(`Area      : ${AREA_NAME}`);
  console.log(`Bounding  : S ${S}  W ${W}  N ${N}  E ${E}`);
  console.log(`Classes   : ${ROAD_CLASSES.join(', ')}`);
  console.log(`Endpoint  : ${ENDPOINT}\n`);

  console.log('Downloading road ways from OpenStreetMap ...');
  const roadData = await overpass(ROAD_QUERY);
  const ways = (roadData.elements || []).filter((e) => e.type === 'way');
  console.log(`  ${ways.length} way(s) received`);
  if (ways.length === 0) throw new Error('No roads returned — check the bounding box.');

  console.log('Downloading hospitals and fire stations ...');
  let places = [];
  try {
    const placeData = await overpass(PLACE_QUERY);
    places = placeData.elements || [];
    console.log(`  ${places.length} facility candidate(s) received`);
  } catch (err) {
    console.log(`  (skipped: ${err.message})`);
  }

  console.log('\nBuilding junction graph ...');
  let { nodes, edges } = buildGraph(ways);
  console.log(`  ${nodes.size} junction(s), ${edges.length} segment(s) before simplification`);

  // Junctions nearest to a facility must survive simplification.
  const facilityAnchors = new Set();
  const facilityPoints = places
    .map((p) => {
      const lat = p.lat ?? p.center?.lat;
      const lon = p.lon ?? p.center?.lon;
      if (lat == null || lon == null) return null;
      const amenity = p.tags?.amenity;
      const name = p.tags?.name;
      if (!name) return null;
      return { lat, lon, amenity, name };
    })
    .filter(Boolean);

  const nearestNode = (lat, lon, pool) => {
    let bestId = null;
    let bestD = Infinity;
    for (const [id, n] of pool) {
      const d = haversine([lat, lon], [n.lat, n.lng]);
      if (d < bestD) {
        bestD = d;
        bestId = id;
      }
    }
    return { id: bestId, distance: bestD };
  };

  for (const p of facilityPoints) {
    const { id, distance } = nearestNode(p.lat, p.lon, nodes);
    if (id && distance < 1200) facilityAnchors.add(id);
  }

  const simplified = simplifyDegreeTwo(nodes, edges, facilityAnchors);
  edges = simplified.edges;
  console.log(`  merged ${simplified.merged} pass-through junction(s)`);

  ({ nodes, edges } = largestComponent(nodes, edges));
  console.log(`  ${nodes.size} junction(s), ${edges.length} segment(s) in the largest connected component`);

  // Thin by road class if the graph is still too large to render comfortably.
  if (nodes.size > MAX_NODES) {
    console.log(`\nGraph exceeds --max-nodes=${MAX_NODES}; dropping the lowest road classes ...`);
    const ranks = [...new Set(edges.map((e) => rankOf(e.roadClass)))].sort((a, b) => a - b);
    for (const cut of ranks) {
      const kept = edges.filter((e) => rankOf(e.roadClass) > cut);
      const trimmed = largestComponent(nodes, kept);
      if (trimmed.nodes.size <= MAX_NODES && trimmed.nodes.size > 40) {
        nodes = trimmed.nodes;
        edges = trimmed.edges;
        console.log(`  dropped classes at rank <= ${cut}: now ${nodes.size} junction(s)`);
        break;
      }
    }
  }

  /* --------------------------------------------------------- output shape */

  const idMap = new Map();
  let seq = 0;
  for (const osmId of nodes.keys()) {
    seq += 1;
    idMap.set(osmId, `J${String(seq).padStart(4, '0')}`);
  }

  const edgesByNode = new Map();
  for (const e of edges) {
    if (!edgesByNode.has(e.from)) edgesByNode.set(e.from, []);
    if (!edgesByNode.has(e.to)) edgesByNode.set(e.to, []);
    edgesByNode.get(e.from).push(e);
    edgesByNode.get(e.to).push(e);
  }

  const outNodes = [];
  let i = 0;
  for (const [osmId, node] of nodes) {
    i += 1;
    outNodes.push({
      id: idMap.get(osmId),
      osmId,
      lat: node.lat,
      lng: node.lng,
      name: nameJunction(node, edgesByNode.get(osmId) || [], i),
      degree: (edgesByNode.get(osmId) || []).length,
    });
  }

  // Deduplicate parallel segments, keeping the shortest.
  const seenPairs = new Map();
  for (const e of edges) {
    const a = idMap.get(e.from);
    const b = idMap.get(e.to);
    if (!a || !b || a === b) continue;
    const key = a < b ? `${a}|${b}` : `${b}|${a}`;
    const geometry = a < b ? e.geometry : e.geometry.slice().reverse();
    const existing = seenPairs.get(key);
    if (!existing || e.length < existing.length) {
      seenPairs.set(key, {
        from: a < b ? a : b,
        to: a < b ? b : a,
        length: Math.max(1, e.length),
        roadName: e.roadName,
        roadClass: e.roadClass,
        geometry,
      });
    }
  }
  const outEdges = [...seenPairs.values()];

  /* ------------------------------------------------------------ facilities */

  const nodesById = new Map(outNodes.map((n) => [n.id, n]));
  const usedNodes = new Set();
  const facilities = [];
  let hospitalSeq = 0;
  let stationSeq = 0;

  const remapPool = new Map(outNodes.map((n) => [n.id, n]));

  const rankedPlaces = facilityPoints.sort((a, b) => {
    const score = (p) => (p.amenity === 'hospital' ? 0 : p.amenity === 'fire_station' ? 0 : 1);
    return score(a) - score(b);
  });

  for (const place of rankedPlaces) {
    const isStation = place.amenity === 'fire_station';
    if (!isStation && place.amenity !== 'hospital') continue;
    if (!isStation && hospitalSeq >= 5) continue;
    if (isStation && stationSeq >= 4) continue;

    const { id, distance } = nearestNode(place.lat, place.lon, remapPool);
    if (!id || distance > 1500 || usedNodes.has(id)) continue;
    usedNodes.add(id);

    if (isStation) {
      stationSeq += 1;
      facilities.push({
        id: `FS-${String(stationSeq).padStart(2, '0')}`,
        type: 'fire_station',
        node: id,
        name: place.name,
        short: place.name.split(/[,(]/)[0].trim().slice(0, 22),
        bays: 2 + (stationSeq % 2),
      });
    } else {
      hospitalSeq += 1;
      facilities.push({
        id: `HOSP-${String(hospitalSeq).padStart(2, '0')}`,
        type: 'hospital',
        node: id,
        name: place.name,
        short: place.name.split(/[,(]/)[0].trim().slice(0, 22),
        beds: 8 + hospitalSeq * 2,
      });
    }
  }

  // Guarantee a usable fleet even where OSM tagging is sparse: spread synthetic
  // facilities over well-connected junctions far apart from each other.
  const ensure = (type, want, namePrefix, idPrefix) => {
    const have = facilities.filter((f) => f.type === type);
    if (have.length >= want) return;
    const candidates = outNodes
      .filter((n) => n.degree >= 3 && !usedNodes.has(n.id))
      .sort((a, b) => b.degree - a.degree);
    let added = have.length;
    for (const cand of candidates) {
      if (added >= want) break;
      const tooClose = facilities.some(
        (f) => haversine([cand.lat, cand.lng], [nodesById.get(f.node).lat, nodesById.get(f.node).lng]) < 1500,
      );
      if (tooClose) continue;
      added += 1;
      usedNodes.add(cand.id);
      facilities.push({
        id: `${idPrefix}-${String(added).padStart(2, '0')}`,
        type,
        node: cand.id,
        name: `${namePrefix} ${added} (${cand.name})`,
        short: `${namePrefix} ${added}`,
        ...(type === 'hospital' ? { beds: 10 } : { bays: 2 }),
        synthetic: true,
      });
    }
  };

  ensure('hospital', 3, 'Emergency Hospital', 'HOSP');
  ensure('fire_station', 2, 'Fire Station', 'FS');

  const lats = outNodes.map((n) => n.lat);
  const lngs = outNodes.map((n) => n.lng);
  const network = {
    meta: {
      placeholder: false,
      area: AREA_NAME,
      source: 'OpenStreetMap contributors (ODbL)',
      generatedAt: new Date().toISOString(),
      bbox: { south: S, west: W, north: N, east: E },
      roadClasses: ROAD_CLASSES,
      junctions: outNodes.length,
      segments: outEdges.length,
    },
    center: {
      lat: round((Math.min(...lats) + Math.max(...lats)) / 2),
      lng: round((Math.min(...lngs) + Math.max(...lngs)) / 2),
    },
    zoom: 14,
    nodes: outNodes,
    edges: outEdges,
    facilities,
  };

  fs.mkdirSync(path.dirname(OUT), { recursive: true });
  fs.writeFileSync(OUT, JSON.stringify(network));

  const kb = (fs.statSync(OUT).size / 1024).toFixed(0);
  console.log('\nWrote', path.relative(PROJECT, OUT), `(${kb} KB)`);
  console.log(`  junctions  ${outNodes.length}`);
  console.log(`  segments   ${outEdges.length}`);
  console.log(`  hospitals  ${facilities.filter((f) => f.type === 'hospital').length}`);
  console.log(`  stations   ${facilities.filter((f) => f.type === 'fire_station').length}`);
  console.log('\nRestart the dev server to pick it up.');
}

main().catch((err) => {
  console.error('\nFailed:', err.message);
  console.error('\nIf Overpass is busy, wait a minute and retry, or try:');
  console.error('  node scripts/fetch-osm-network.mjs --endpoint=https://overpass.kumi.systems/api/interpreter');
  process.exit(1);
});
