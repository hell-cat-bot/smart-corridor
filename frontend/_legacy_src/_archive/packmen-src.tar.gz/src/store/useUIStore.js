import { create } from 'zustand';

const useUIStore = create((set) => ({
  sidebarCollapsed: false,
  bottomPanelOpen: true,
  activeBottomTab: 'mission',

  selectedMissionId: null,
  selectedUnitId: null,
  selectedNodeId: null,
  focusUnitId: null,

  showMissionDialog: false,
  showDisasterDialog: false,
  disasterDialogNode: null,

  /** Log view filters live here so they survive navigation. */
  logFilters: { categories: [], severity: 'all', query: '' },

  setSidebarCollapsed: (sidebarCollapsed) => set({ sidebarCollapsed }),
  setBottomPanelOpen: (bottomPanelOpen) => set({ bottomPanelOpen }),
  setActiveBottomTab: (activeBottomTab) => set({ activeBottomTab }),

  setSelectedMissionId: (selectedMissionId) => set({ selectedMissionId }),
  setSelectedUnitId: (selectedUnitId) => set({ selectedUnitId }),
  setSelectedNodeId: (selectedNodeId) => set({ selectedNodeId }),
  setFocusUnitId: (focusUnitId) => set({ focusUnitId }),

  setShowMissionDialog: (showMissionDialog) => set({ showMissionDialog }),
  openDisasterDialog: (node = null) => set({ showDisasterDialog: true, disasterDialogNode: node }),
  closeDisasterDialog: () => set({ showDisasterDialog: false, disasterDialogNode: null }),

  setLogFilters: (patch) =>
    set((state) => ({ logFilters: { ...state.logFilters, ...patch } })),

  clearSelection: () => set({ selectedMissionId: null, selectedUnitId: null, selectedNodeId: null }),
}));

export default useUIStore;
