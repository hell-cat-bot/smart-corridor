import { create } from 'zustand';
import { LOG_CATEGORY, SEVERITY } from '../domain/constants';

const MAX_ENTRIES = 800;
let seq = 0;

/**
 * Structured, categorised operations log.
 *
 * Every record carries wall-clock time, simulation time, a category, entity
 * references and the structured data behind the decision — so a routing choice
 * or a junction tie-break can be traced after the fact, not just read as prose.
 */
const useLogStore = create((set, get) => ({
  entries: [],

  log: ({
    category = LOG_CATEGORY.SIMULATION,
    severity = SEVERITY.INFO,
    message,
    simTime = 0,
    refs = {},
    data = {},
  }) => {
    seq += 1;
    const entry = {
      id: `LOG-${seq}`,
      seq,
      wallTime: new Date().toISOString(),
      simTime,
      category,
      severity,
      message,
      refs,
      data,
    };
    set((state) => ({
      entries: [entry, ...state.entries].slice(0, MAX_ENTRIES),
    }));
    return entry;
  },

  clear: () => set({ entries: [] }),

  countsByCategory: () => {
    const counts = {};
    for (const entry of get().entries) {
      counts[entry.category] = (counts[entry.category] || 0) + 1;
    }
    return counts;
  },

  exportJson: () => JSON.stringify(get().entries, null, 2),
}));

/** Convenience wrapper so engine modules can log without pulling the hook in. */
export function logEvent(payload) {
  return useLogStore.getState().log(payload);
}

export default useLogStore;
