/**
 * Route planning helpers shared by dispatch, the mission engine and the UI.
 *
 * A route carries two parallel measurements: `coords`/`cumulative` follow the
 * real road polyline (what the vehicle drives and the map draws), and
 * `nodeCumulative` records how far along that polyline each junction sits (what
 * preemption, replanning and ETAs reason about).
 */

import useSettingsStore from '../store/useSettingsStore';
import useWorldStore from '../store/useWorldStore';
import { planRoute, pathTravelTime, pathFreeFlowTime } from '../utils/pathfinding';
import { measurePath, indexNodes, nextNodeIndex } from '../utils/geo';
import { FREE_FLOW_SPEED, UNIT_TYPE } from '../domain/constants';

export function omegaFor(unitType) {
  const { priorityWeights } = useSettingsStore.getState();
  return priorityWeights[unitType] ?? 1.0;
}

export function baseSpeedFor(unitType) {
  return FREE_FLOW_SPEED[unitType] ?? FREE_FLOW_SPEED[UNIT_TYPE.AMBULANCE];
}

/** Snapshot of everything routing needs, read once per planning call. */
export function routingContext() {
  const world = useWorldStore.getState();
  const settings = useSettingsStore.getState();
  const congestion = {};
  for (const n of world.nodes) congestion[n.id] = n.congestion;
  return {
    nodes: world.nodes,
    edges: world.edges,
    edgeIndex: world.edgeIndex,
    nodeMap: indexNodes(world.nodes),
    congestion,
    blocked: new Set(world.disasters.map((d) => d.node)),
    alpha: settings.congestionFactor,
  };
}

/**
 * Plan a single leg. Returns null when no feasible path exists (for example
 * when a disaster has cut the destination off entirely).
 */
export function planLeg({ from, to, unitType, ctx = null, algorithm = 'astar' }) {
  const context = ctx || routingContext();
  const result = planRoute({
    nodes: context.nodes,
    edges: context.edges,
    from,
    to,
    blocked: context.blocked,
    congestion: context.congestion,
    alpha: context.alpha,
    omega: omegaFor(unitType),
    unitType,
    algorithm,
    edgeIndex: context.edgeIndex,
    nodeMap: context.nodeMap,
  });
  if (!result.found) return null;
  return result;
}

/**
 * Turn a planned path into a travellable route: the measured road polyline plus
 * the bookkeeping the simulation needs (metres travelled, previous path kept for
 * the dashed comparison line).
 */
export function buildRoute({ path, ctx, legType, destNode, originalPath = null, unitType }) {
  const context = ctx || routingContext();
  const { coords, cumulative, nodeCumulative, total } = measurePath(path, context);
  return {
    path,
    coords,
    cumulative,
    nodeCumulative,
    total,
    travelled: 0,
    legType,
    destNode,
    originalPath,
    unitType,
    plannedAt: useWorldStore.getState().simTime,
  };
}

/** Re-measure a route after a replan. The unit restarts from the new anchor. */
export function rebuildRoute(route, path, ctx, keepOriginal = true) {
  const context = ctx || routingContext();
  const { coords, cumulative, nodeCumulative, total } = measurePath(path, context);
  return {
    ...route,
    path,
    coords,
    cumulative,
    nodeCumulative,
    total,
    travelled: 0,
    originalPath: keepOriginal ? route.path : route.originalPath,
    plannedAt: useWorldStore.getState().simTime,
  };
}

/** Remaining travel time on a route under current congestion. */
export function remainingEta(route, ctx, unitType) {
  if (!route) return 0;
  const context = ctx || routingContext();
  const idx = nextNodeIndex(route.nodeCumulative, route.travelled);
  const remainingPath = route.path.slice(Math.max(0, idx - 1));
  return pathTravelTime(
    remainingPath,
    context.nodeMap,
    context.congestion,
    baseSpeedFor(unitType),
    context.edgeIndex,
  );
}

export function freeFlowEta(path, ctx, unitType) {
  const context = ctx || routingContext();
  return pathFreeFlowTime(path, context.nodeMap, baseSpeedFor(unitType), context.edgeIndex);
}

/** The junction a unit is heading into — the anchor for any mid-route replan. */
export function replanAnchor(route) {
  if (!route || route.path.length === 0) return null;
  return route.path[nextNodeIndex(route.nodeCumulative, route.travelled)];
}

/** Does the not-yet-travelled part of this route still touch a blocked junction? */
export function routeHitsBlocked(route, blocked) {
  if (!route) return null;
  const anchorIndex = nextNodeIndex(route.nodeCumulative, route.travelled);
  for (let i = anchorIndex; i < route.path.length; i += 1) {
    if (blocked.has(route.path[i])) return route.path[i];
  }
  return null;
}
