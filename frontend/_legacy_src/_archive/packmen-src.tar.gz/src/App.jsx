import React, { useEffect } from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';

import Landing from './components/Landing';
import Sidebar from './components/layout/Sidebar';
import TopBar from './components/layout/TopBar';

import OperationsView from './components/views/OperationsView';
import GreenCorridorView from './components/views/GreenCorridorView';
import MissionsView from './components/views/MissionsView';
import FleetView from './components/views/FleetView';
import DisastersView from './components/views/DisastersView';
import AnalyticsView from './components/views/AnalyticsView';
import LogsView from './components/views/LogsView';
import SettingsView from './components/views/SettingsView';

import NewMissionDialog from './components/panels/NewMissionDialog';
import DisasterDialog from './components/panels/DisasterDialog';

import { initWorld } from './engine/simulation';

/**
 * Application shell.
 *
 *   Operations       map, missions, units, disasters, live A*, congestion
 *   Green Corridor   frozen path, traffic lights, preemption, conflicts
 *   Missions         dispatch queue, active missions, history, route detail
 *   Fleet            units and facilities
 *   Disasters        active blockages
 *   Shared           analytics, structured logs, settings, demo world, reset
 */
function Shell({ children }) {
  return (
    <div className="flex h-screen w-screen bg-background overflow-hidden select-none">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden min-w-0">
        <TopBar />
        <div className="flex-1 flex flex-col overflow-hidden min-h-0">{children}</div>
      </div>
      <NewMissionDialog />
      <DisasterDialog />
    </div>
  );
}

export default function App() {
  const location = useLocation();

  useEffect(() => {
    initWorld();
  }, []);

  if (location.pathname === '/') return <Landing />;

  return (
    <Shell>
      <Routes>
        <Route path="/operations" element={<OperationsView />} />
        <Route path="/corridor" element={<GreenCorridorView />} />
        <Route path="/missions" element={<MissionsView />} />
        <Route path="/fleet" element={<FleetView />} />
        <Route path="/disasters" element={<DisastersView />} />
        <Route path="/analytics" element={<AnalyticsView />} />
        <Route path="/logs" element={<LogsView />} />
        <Route path="/settings" element={<SettingsView />} />
        <Route path="*" element={<Navigate to="/operations" replace />} />
      </Routes>
    </Shell>
  );
}
