import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  TrafficCone,
  ListOrdered,
  Truck,
  AlertTriangle,
  BarChart3,
  ScrollText,
  Settings,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import useUIStore from '../../store/useUIStore';
import useWorldStore from '../../store/useWorldStore';
import { MISSION_STATUS, ACTIVE_MISSION_STATUSES } from '../../domain/constants';

const navItems = [
  { name: 'Operations', path: '/operations', icon: LayoutDashboard, group: 'Live' },
  { name: 'Green Corridor', path: '/corridor', icon: TrafficCone, group: 'Live' },
  { name: 'Missions', path: '/missions', icon: ListOrdered, group: 'Manage', badge: 'pending' },
  { name: 'Fleet & Facilities', path: '/fleet', icon: Truck, group: 'Manage' },
  { name: 'Disasters', path: '/disasters', icon: AlertTriangle, group: 'Manage', badge: 'disasters' },
  { name: 'Analytics', path: '/analytics', icon: BarChart3, group: 'Shared' },
  { name: 'Logs', path: '/logs', icon: ScrollText, group: 'Shared' },
  { name: 'Settings', path: '/settings', icon: Settings, group: 'Shared' },
];

export default function Sidebar() {
  const collapsed = useUIStore((s) => s.sidebarCollapsed);
  const setCollapsed = useUIStore((s) => s.setSidebarCollapsed);
  const missions = useWorldStore((s) => s.missions);
  const disasters = useWorldStore((s) => s.disasters);

  const pending = missions.filter((m) => m.status === MISSION_STATUS.PENDING).length;
  const active = missions.filter((m) => ACTIVE_MISSION_STATUSES.includes(m.status)).length;

  const badgeValue = (key) => {
    if (key === 'pending') return pending || null;
    if (key === 'disasters') return disasters.length || null;
    return null;
  };

  let lastGroup = null;

  return (
    <div
      className={`bg-white border-r border-[#E5E7EB] flex flex-col transition-all duration-300 h-screen shrink-0 z-40 ${
        collapsed ? 'w-16' : 'w-60'
      }`}
    >
      <div className="flex items-center h-16 border-b border-[#E5E7EB] px-4 shrink-0">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 rounded-lg bg-[#7C6FEF] flex items-center justify-center text-white shrink-0 shadow-sm shadow-[#7C6FEF]/25">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" />
            </svg>
          </div>
          {!collapsed && (
            <div className="min-w-0">
              <p className="text-sm font-bold text-gray-900 tracking-tight leading-tight">Packmen</p>
              <p className="text-[9.5px] text-gray-400 font-semibold uppercase tracking-wider">Smart Corridor</p>
            </div>
          )}
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto py-3 px-2.5 flex flex-col gap-0.5 min-h-0">
        {navItems.map((item) => {
          const showGroup = !collapsed && item.group !== lastGroup;
          lastGroup = item.group;
          const badge = badgeValue(item.badge);

          return (
            <React.Fragment key={item.name}>
              {showGroup && (
                <span className="px-2 pt-3 pb-1 text-[9px] font-bold uppercase tracking-widest text-gray-300">
                  {item.group}
                </span>
              )}
              <NavLink
                to={item.path}
                title={collapsed ? item.name : undefined}
                className={({ isActive }) =>
                  `flex items-center gap-2.5 px-2.5 py-2 rounded-lg transition-colors shrink-0 ${
                    isActive
                      ? 'bg-[#7C6FEF] text-white shadow-sm shadow-[#7C6FEF]/25 font-semibold'
                      : 'text-[#6B7280] hover:bg-gray-50 hover:text-gray-900 font-medium'
                  } ${collapsed ? 'justify-center' : ''}`
                }
              >
                <item.icon className="w-4 h-4 shrink-0" />
                {!collapsed && <span className="text-[11.5px] whitespace-nowrap flex-1">{item.name}</span>}
                {!collapsed && badge != null && (
                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-white/25 text-current border border-current/20">
                    {badge}
                  </span>
                )}
              </NavLink>
            </React.Fragment>
          );
        })}
      </nav>

      <div className="p-2.5 border-t border-[#E5E7EB] space-y-2 shrink-0 bg-gray-50/50">
        {!collapsed && (
          <div className="px-2 py-1.5 rounded-lg bg-white border border-[#E5E7EB]">
            <p className="text-[9px] font-bold uppercase tracking-wider text-gray-400">World state</p>
            <p className="text-[10.5px] text-gray-600 mt-0.5">
              {active} active · {pending} pending · {disasters.length} blocked
            </p>
          </div>
        )}
        <div className={`flex items-center gap-2.5 px-2 ${collapsed ? 'justify-center' : ''}`}>
          <div className="w-7 h-7 rounded-full bg-[#EDE9FE] text-[#7C6FEF] flex items-center justify-center font-bold text-[10px] shrink-0">
            OP
          </div>
          {!collapsed && (
            <div className="flex flex-col min-w-0">
              <span className="text-[11px] font-semibold text-gray-900 truncate">Operator</span>
              <span className="text-[9.5px] text-[#6B7280] truncate">Control room</span>
            </div>
          )}
        </div>

        <button
          onClick={() => setCollapsed(!collapsed)}
          className="flex items-center justify-center w-full py-1.5 text-[#6B7280] hover:bg-gray-200/50 hover:text-gray-900 rounded-lg transition-colors"
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>
    </div>
  );
}
