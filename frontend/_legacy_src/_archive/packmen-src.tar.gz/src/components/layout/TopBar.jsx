import React from 'react';
import { useLocation } from 'react-router-dom';
import { Plus, AlertCircle, Radio, Zap } from 'lucide-react';
import useUIStore from '../../store/useUIStore';
import useWorldStore from '../../store/useWorldStore';
import useSettingsStore from '../../store/useSettingsStore';
import { Button } from '../common/ui';
import { formatSimClock } from '../../utils/geo';

const pageTitles = {
  '/operations': { title: 'Operations', sub: 'Missions, disasters, live routing and congestion on the corridor grid' },
  '/corridor': { title: 'Green Corridor', sub: 'Frozen path, signal preemption and multi-vehicle junction arbitration' },
  '/missions': { title: 'Missions', sub: 'Dispatch queue, active missions and mission history' },
  '/fleet': { title: 'Fleet & Facilities', sub: 'Response units, hospitals and fire stations' },
  '/disasters': { title: 'Disasters', sub: 'Active blockages on the network' },
  '/analytics': { title: 'Analytics', sub: 'Response and corridor performance' },
  '/logs': { title: 'Structured logs', sub: 'Categorised, traceable record of every system decision' },
  '/settings': { title: 'Settings & calibration', sub: 'Routing weights, congestion model, signals and demo world' },
};

export default function TopBar() {
  const location = useLocation();
  const setShowMissionDialog = useUIStore((s) => s.setShowMissionDialog);
  const openDisasterDialog = useUIStore((s) => s.openDisasterDialog);

  const running = useWorldStore((s) => s.running);
  const simTime = useWorldStore((s) => s.simTime);
  const lights = useWorldStore((s) => s.lights);
  const autoApprove = useSettingsStore((s) => s.autoApprove);

  const page = pageTitles[location.pathname] || pageTitles['/operations'];
  const preempted = Object.keys(lights).length;

  return (
    <div className="h-16 bg-white border-b border-[#E5E7EB] flex items-center justify-between px-5 shrink-0 gap-4">
      <div className="min-w-0">
        <h1 className="font-semibold text-base text-gray-900 leading-tight truncate">{page.title}</h1>
        <p className="text-[11px] text-gray-500 truncate">{page.sub}</p>
      </div>

      <div className="flex items-center gap-2.5 shrink-0">
        <div className="hidden lg:flex items-center gap-3 px-3 py-1.5 rounded-lg bg-gray-50 border border-[#E5E7EB]">
          <span className="flex items-center gap-1.5 text-[10.5px] font-semibold text-gray-600">
            <span className={`w-1.5 h-1.5 rounded-full ${running ? 'bg-green-500 animate-pulse' : 'bg-gray-300'}`} />
            {running ? 'Running' : 'Paused'}
          </span>
          <span className="text-[10.5px] font-mono font-bold text-gray-700 tabular-nums">{formatSimClock(simTime)}</span>
          <span className="flex items-center gap-1 text-[10.5px] font-semibold text-green-700">
            <Zap className="w-3 h-3" />
            {preempted} preempted
          </span>
          <span className="flex items-center gap-1 text-[10.5px] font-semibold text-[#7C6FEF]">
            <Radio className="w-3 h-3" />
            5G-URLLC
          </span>
        </div>

        {autoApprove && (
          <span className="text-[10px] font-bold px-2 py-1 rounded-full bg-amber-50 text-amber-700 border border-amber-200">
            AUTO-APPROVE
          </span>
        )}

        <Button variant="ghost" onClick={() => openDisasterDialog(null)}>
          <AlertCircle className="w-3.5 h-3.5" />
          Inject disaster
        </Button>

        <Button onClick={() => setShowMissionDialog(true)}>
          <Plus className="w-3.5 h-3.5" />
          New mission
        </Button>
      </div>
    </div>
  );
}
