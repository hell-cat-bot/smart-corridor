import React from 'react';
import { GitCommit, ListOrdered, Gauge, History, ChevronUp, ChevronDown } from 'lucide-react';
import useUIStore from '../../store/useUIStore';
import MissionDetail from '../panels/MissionDetail';
import MissionQueue from '../panels/MissionQueue';
import CongestionPanel from '../panels/CongestionPanel';
import LogFeed from '../panels/LogFeed';

const tabs = [
  { id: 'mission', label: 'Mission & route', icon: GitCommit, component: MissionDetail },
  { id: 'queue', label: 'Dispatch queue', icon: ListOrdered, component: MissionQueue },
  { id: 'congestion', label: 'Congestion', icon: Gauge, component: CongestionPanel },
  { id: 'log', label: 'Event log', icon: History, component: LogFeed },
];

export default function BottomPanel() {
  const open = useUIStore((s) => s.bottomPanelOpen);
  const setOpen = useUIStore((s) => s.setBottomPanelOpen);
  const activeTab = useUIStore((s) => s.activeBottomTab);
  const setActiveTab = useUIStore((s) => s.setActiveBottomTab);

  const Active = tabs.find((t) => t.id === activeTab)?.component || MissionDetail;

  return (
    <div
      className={`w-full bg-white border-t border-[#E5E7EB] shadow-[0_-4px_12px_rgba(0,0,0,0.03)] transition-all duration-300 flex flex-col shrink-0 ${
        open ? 'h-72' : 'h-11'
      }`}
    >
      <div
        className="h-11 flex items-center justify-between px-5 bg-gray-50 border-b border-[#E5E7EB] select-none cursor-pointer shrink-0"
        onClick={() => setOpen(!open)}
      >
        <div className="flex gap-1.5">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={(e) => {
                e.stopPropagation();
                setActiveTab(tab.id);
                if (!open) setOpen(true);
              }}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[11px] font-semibold transition-all ${
                activeTab === tab.id
                  ? 'text-[#7C6FEF] bg-white border border-[#E5E7EB] shadow-sm'
                  : 'text-gray-500 hover:text-gray-700 hover:bg-gray-100'
              }`}
            >
              <tab.icon className="w-3.5 h-3.5" />
              {tab.label}
            </button>
          ))}
        </div>

        <button
          onClick={(e) => {
            e.stopPropagation();
            setOpen(!open);
          }}
          className="p-1.5 hover:bg-gray-200 text-gray-400 hover:text-gray-600 rounded-md transition-colors"
        >
          {open ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
        </button>
      </div>

      <div className={`flex-1 min-h-0 overflow-y-auto p-4 bg-white ${open ? 'block' : 'hidden'}`}>
        <Active />
      </div>
    </div>
  );
}
