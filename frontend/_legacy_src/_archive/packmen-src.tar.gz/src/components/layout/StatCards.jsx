import React from 'react';
import { Clock, AlertTriangle, GitBranch, Activity, Zap, Ambulance } from 'lucide-react';
import useWorldStore from '../../store/useWorldStore';
import { StatTile } from '../common/ui';
import { ACTIVE_MISSION_STATUSES, UNIT_STATUS, NODE_STATUS } from '../../domain/constants';
import { formatDuration } from '../../utils/geo';

/** Headline numbers for the operations view. */
export default function StatCards() {
  const missions = useWorldStore((s) => s.missions);
  const units = useWorldStore((s) => s.units);
  const nodes = useWorldStore((s) => s.nodes);
  const disasters = useWorldStore((s) => s.disasters);
  const lights = useWorldStore((s) => s.lights);
  const metrics = useWorldStore((s) => s.metrics);

  const active = missions.filter((m) => ACTIVE_MISSION_STATUSES.includes(m.status)).length;
  const available = units.filter((u) => u.status === UNIT_STATUS.AVAILABLE).length;
  const congested = nodes.filter((n) => n.status === NODE_STATUS.CONGESTED).length;
  const meanCongestion = nodes.length
    ? Math.round((nodes.reduce((s, n) => s + n.congestion, 0) / nodes.length) * 100)
    : 0;

  const avgResponse = metrics.responseTimes.length
    ? metrics.responseTimes.reduce((a, b) => a + b, 0) / metrics.responseTimes.length
    : null;

  const stats = [
    {
      label: 'Avg response time',
      value: avgResponse == null ? '—' : formatDuration(avgResponse),
      hint: `${metrics.responseTimes.length} mission(s) measured`,
      icon: Clock,
      tone: 'bg-[#DCFCE7] text-[#16A34A]',
    },
    {
      label: 'Active missions',
      value: active,
      hint: `${available}/${units.length} units available`,
      icon: Ambulance,
      tone: 'bg-[#EDE9FE] text-[#7C6FEF]',
    },
    {
      label: 'Rerouted legs',
      value: metrics.replans,
      hint: `${metrics.blockageReplans} blockage · ${metrics.congestionReplans} congestion`,
      icon: GitBranch,
      tone: 'bg-[#DBEAFE] text-[#2563EB]',
    },
    {
      label: 'Preempted junctions',
      value: Object.keys(lights).length,
      hint: `${metrics.conflictsResolved} conflict(s) arbitrated`,
      icon: Zap,
      tone: 'bg-[#DCFCE7] text-[#16A34A]',
    },
    {
      label: 'Congestion index',
      value: `${meanCongestion}%`,
      hint: `${congested} junction(s) above threshold`,
      icon: Activity,
      tone: 'bg-[#FEF3C7] text-[#D97706]',
    },
    {
      label: 'Active disasters',
      value: disasters.length,
      hint: disasters.length ? disasters.map((d) => d.node).join(', ') : 'network clear',
      icon: AlertTriangle,
      tone: 'bg-[#FEE2E2] text-[#DC2626]',
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
      {stats.map((s) => (
        <StatTile key={s.label} {...s} />
      ))}
    </div>
  );
}
