import React, { useMemo, useState } from 'react';
import { GitCompare, Route as RouteIcon } from 'lucide-react';
import useWorldStore from '../../store/useWorldStore';
import useUIStore from '../../store/useUIStore';
import useSettingsStore from '../../store/useSettingsStore';
import { planRoute } from '../../utils/pathfinding';
import { omegaFor } from '../../engine/routing';
import { liveEta } from '../../engine/simulation';
import {
  MISSION_STATUS,
  MISSION_STATUS_LABEL,
  LEG_LABEL,
  ACTIVE_MISSION_STATUSES,
} from '../../domain/constants';
import { formatDuration, formatMeters } from '../../utils/geo';
import { Badge, EmptyState, KeyValue, Button } from '../common/ui';

function PathTrail({ path, blocked = new Set(), highlight = '#7C6FEF' }) {
  // Junction ids are compact on a real network; the tooltip carries the name.
  return (
    <div className="flex flex-wrap gap-1 mt-2">
      {path.map((id, i) => (
        <span
          key={`${id}-${i}`}
          className={`px-1.5 py-0.5 rounded text-[9.5px] font-mono font-semibold ${
            blocked.has(id) ? 'bg-red-100 text-red-700 line-through' : 'bg-gray-100 text-gray-600'
          }`}
          style={!blocked.has(id) && (i === 0 || i === path.length - 1) ? { color: highlight } : undefined}
        >
          {id.replace(/^J0*/, '')}
        </span>
      ))}
    </div>
  );
}

/** Route detail for the selected mission, with the A* / comparison split. */
export default function MissionDetail() {
  const selectedMissionId = useUIStore((s) => s.selectedMissionId);
  const missions = useWorldStore((s) => s.missions);
  const units = useWorldStore((s) => s.units);
  const nodes = useWorldStore((s) => s.nodes);
  const edges = useWorldStore((s) => s.edges);
  const disasters = useWorldStore((s) => s.disasters);
  const alpha = useSettingsStore((s) => s.congestionFactor);
  const edgeIndex = useWorldStore((s) => s.edgeIndex);

  const [compareMode, setCompareMode] = useState('auto');

  const mission = missions.find((m) => m.id === selectedMissionId) || null;
  const unit = mission ? units.find((u) => u.id === mission.unitId) : null;
  const leg = mission && mission.activeLeg >= 0 ? mission.legs[mission.activeLeg] : null;

  const blocked = useMemo(() => new Set(disasters.map((d) => d.node)), [disasters]);
  const congestion = useMemo(() => Object.fromEntries(nodes.map((n) => [n.id, n.congestion])), [nodes]);

  const dijkstraRoute = useMemo(() => {
    if (!leg) return null;
    return planRoute({
      nodes,
      edges,
      from: leg.path[0],
      to: leg.to,
      blocked,
      congestion,
      alpha,
      omega: omegaFor(unit?.type ?? 'ambulance'),
      unitType: unit?.type ?? 'ambulance',
      algorithm: 'dijkstra',
      edgeIndex,
    });
  }, [leg, nodes, edges, blocked, congestion, alpha, unit?.type, edgeIndex]);

  if (!mission) {
    return (
      <EmptyState
        icon={RouteIcon}
        title="No mission selected"
        hint="Pick a mission from the dispatch queue or click a unit on the map to inspect its route."
      />
    );
  }

  const showOriginal = leg?.originalPath && (compareMode === 'auto' || compareMode === 'original');
  const liveRemaining = unit ? liveEta(unit) : null;

  const timeline = [
    { label: 'Call created', at: mission.createdAt },
    { label: 'Dispatch approved', at: mission.approvedAt },
    { label: 'On scene', at: mission.onSceneAt },
    { label: 'Completed', at: mission.completedAt },
  ];

  return (
    <div className="grid lg:grid-cols-2 gap-4">
      {/* ------------------------------------------------------- live route */}
      <div className="rounded-xl border border-[#E5E7EB] p-3">
        <div className="flex items-center justify-between mb-2">
          <h4 className="text-[11px] font-bold uppercase tracking-wider text-gray-400">
            Live route · A* with live congestion
          </h4>
          <Badge tone="bg-[#EDE9FE] text-[#7C6FEF]">{MISSION_STATUS_LABEL[mission.status]}</Badge>
        </div>

        {leg ? (
          <>
            <p className="text-[11px] font-semibold text-gray-800 mb-1">{LEG_LABEL[leg.type] ?? leg.type}</p>
            <KeyValue label="Unit" value={unit?.label ?? '—'} />
            <KeyValue label="Junctions" value={leg.path.length} />
            <KeyValue label="Distance" value={formatMeters(leg.distance)} />
            <KeyValue label="Planned ETA" value={formatDuration(leg.plannedEta)} />
            {liveRemaining != null && ACTIVE_MISSION_STATUSES.includes(mission.status) && (
              <KeyValue label="Remaining ETA" value={formatDuration(liveRemaining)} />
            )}
            <KeyValue label="Free-flow ETA" value={formatDuration(leg.freeFlowEta)} />
            <KeyValue label="Replans on this leg" value={leg.replans} />
            <PathTrail path={leg.path} />
          </>
        ) : (
          <p className="text-[11px] text-gray-400 italic py-4">
            {mission.status === MISSION_STATUS.PENDING
              ? 'No leg planned yet — approve the mission to dispatch a unit.'
              : mission.status === MISSION_STATUS.ON_SCENE
                ? 'Unit is on scene. Leg 2 is planned when the dwell period ends.'
                : 'Mission has no active leg.'}
          </p>
        )}
      </div>

      {/* -------------------------------------------------------- comparison */}
      <div className="rounded-xl border border-[#E5E7EB] p-3">
        <div className="flex items-center justify-between mb-2">
          <h4 className="text-[11px] font-bold uppercase tracking-wider text-gray-400 flex items-center gap-1.5">
            <GitCompare className="w-3.5 h-3.5" />
            Comparison
          </h4>
          <div className="flex gap-1">
            <Button
              variant={showOriginal ? 'primary' : 'ghost'}
              className="!px-2 !py-1 !text-[10px]"
              onClick={() => setCompareMode('original')}
              disabled={!leg?.originalPath}
            >
              Pre-replan
            </Button>
            <Button
              variant={!showOriginal ? 'primary' : 'ghost'}
              className="!px-2 !py-1 !text-[10px]"
              onClick={() => setCompareMode('dijkstra')}
            >
              Dijkstra
            </Button>
          </div>
        </div>

        {showOriginal ? (
          <>
            <p className="text-[11px] font-semibold text-red-600 mb-1">Path before the blockage-driven replan</p>
            <KeyValue label="Junctions" value={leg.originalPath.length} />
            <KeyValue
              label="Blocked nodes on it"
              value={leg.originalPath.filter((id) => blocked.has(id)).join(', ') || 'none (cleared since)'}
            />
            <PathTrail path={leg.originalPath} blocked={blocked} />
            <p className="text-[10px] text-gray-400 mt-2">
              Drawn on the map as the dashed red line for as long as the leg is running.
            </p>
          </>
        ) : leg && dijkstraRoute?.found ? (
          <>
            <p className="text-[11px] font-semibold text-gray-800 mb-1">Dijkstra baseline (no heuristic)</p>
            <KeyValue label="Junctions" value={dijkstraRoute.path.length} />
            <KeyValue label="Distance" value={formatMeters(dijkstraRoute.distance)} />
            <KeyValue label="ETA" value={formatDuration(dijkstraRoute.eta)} />
            <KeyValue label="Nodes expanded" value={dijkstraRoute.expanded} />
            <KeyValue
              label="Same as A*?"
              value={dijkstraRoute.path.join('>') === leg.path.join('>') ? 'identical path' : 'different path'}
            />
            <PathTrail path={dijkstraRoute.path} blocked={blocked} highlight="#0891B2" />
            <p className="text-[10px] text-gray-400 mt-2">
              Both price the same cost function; A* reaches it with fewer expansions thanks to the haversine heuristic.
            </p>
          </>
        ) : (
          <p className="text-[11px] text-gray-400 italic py-4">No leg to compare yet.</p>
        )}
      </div>

      {/* ---------------------------------------------------------- timeline */}
      <div className="rounded-xl border border-[#E5E7EB] p-3 lg:col-span-2">
        <h4 className="text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-2">Mission timeline</h4>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {timeline.map((step) => (
            <div key={step.label} className="rounded-lg bg-gray-50 border border-gray-100 p-2.5">
              <p className="text-[10px] text-gray-500">{step.label}</p>
              <p className={`text-sm font-semibold tabular-nums ${step.at == null ? 'text-gray-300' : 'text-gray-900'}`}>
                {step.at == null ? '—' : `T+${Math.round(step.at)}s`}
              </p>
            </div>
          ))}
        </div>
        {mission.onSceneAt != null && (
          <p className="text-[11px] text-gray-600 mt-2">
            Response time {formatDuration(mission.onSceneAt - mission.createdAt)}
            {mission.completedAt != null && ` · total mission ${formatDuration(mission.completedAt - mission.createdAt)}`}
          </p>
        )}
        {mission.note && <p className="text-[11px] text-gray-500 mt-2 italic">Caller note: {mission.note}</p>}
      </div>
    </div>
  );
}
