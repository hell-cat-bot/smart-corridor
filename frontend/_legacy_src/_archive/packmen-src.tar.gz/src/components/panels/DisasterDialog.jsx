import React, { useState, useEffect } from 'react';
import { toast } from 'sonner';
import useUIStore from '../../store/useUIStore';
import useWorldStore from '../../store/useWorldStore';
import { injectDisaster } from '../../engine/disasters';
import { DISASTER_TYPES } from '../../domain/constants';
import { Modal, Field, Select, Button, Meter } from '../common/ui';
import NodePicker from '../common/NodePicker';

export default function DisasterDialog() {
  const open = useUIStore((s) => s.showDisasterDialog);
  const presetNode = useUIStore((s) => s.disasterDialogNode);
  const close = useUIStore((s) => s.closeDisasterDialog);
  const nodes = useWorldStore((s) => s.nodes);
  const disasters = useWorldStore((s) => s.disasters);
  const units = useWorldStore((s) => s.units);

  const [type, setType] = useState('flood');
  const [node, setNode] = useState(presetNode || null);
  const [severity, setSeverity] = useState(0.85);

  useEffect(() => {
    if (presetNode) setNode(presetNode);
  }, [presetNode]);

  if (!open) return null;

  const alreadyBlocked = disasters.some((d) => d.node === node);
  const affected = units.filter((u) => u.route?.path.includes(node));

  const submit = (e) => {
    e.preventDefault();
    const created = injectDisaster({ node, type, severity });
    if (created) {
      toast.error(`${created.label}`);
      close();
    } else {
      toast.warning('Could not inject — junction already blocked or disaster limit reached');
    }
  };

  return (
    <Modal
      title="Inject disaster"
      subtitle="A blocked junction is removed from the routing graph entirely, and every active leg crossing it replans"
      onClose={close}
      footer={
        <>
          <Button variant="subtle" onClick={close}>
            Cancel
          </Button>
          <Button variant="danger" onClick={submit} disabled={!node || alreadyBlocked}>
            {!node ? 'Pick a junction' : alreadyBlocked ? 'Junction already blocked' : 'Inject disaster'}
          </Button>
        </>
      }
    >
      <form onSubmit={submit} className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <Field label="Disaster type">
            <Select value={type} onChange={(e) => setType(e.target.value)}>
              {DISASTER_TYPES.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.label}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Junction">
            <NodePicker value={node} onChange={setNode} placeholder="Search a road or junction" />
          </Field>
        </div>

        <Field label={`Severity — ${Math.round(severity * 100)}%`} hint="Severity is reported to operators; blockage itself is absolute.">
          <input
            type="range"
            min="0.1"
            max="1"
            step="0.05"
            value={severity}
            onChange={(e) => setSeverity(Number(e.target.value))}
            className="w-full accent-[#7C6FEF]"
          />
          <div className="mt-2">
            <Meter value={severity} tone="bg-red-500" />
          </div>
        </Field>

        <div className="rounded-lg bg-amber-50 border border-amber-200 p-3">
          <p className="text-[11px] font-semibold text-amber-800 mb-1">Immediate consequences</p>
          <ul className="text-[11px] text-amber-700 space-y-0.5 list-disc list-inside">
            <li>Junction status becomes blocked and any green wave held there is dropped</li>
            <li>
              {affected.length === 0
                ? 'No active leg currently crosses this junction'
                : `${affected.length} active leg(s) replan immediately: ${affected.map((u) => u.id).join(', ')}`}
            </li>
            <li>The pre-blockage path is kept on the map as the dashed comparison route</li>
          </ul>
        </div>
      </form>
    </Modal>
  );
}
