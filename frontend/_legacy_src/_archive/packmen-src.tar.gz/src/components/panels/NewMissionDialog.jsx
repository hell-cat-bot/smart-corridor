import React, { useMemo, useState } from 'react';
import { toast } from 'sonner';
import useUIStore from '../../store/useUIStore';
import useWorldStore from '../../store/useWorldStore';
import useSettingsStore from '../../store/useSettingsStore';
import { createMission, rankUnits, chooseHospital } from '../../engine/missions';
import {
  SERVICE,
  SERVICE_LABEL,
  EMERGENCY_CLASSES,
  PRIORITY_LABEL,
  findEmergencyClass,
  FACILITY_TYPE,
} from '../../domain/constants';
import { Modal, Field, Select, Input, Button, KeyValue, Badge } from '../common/ui';
import NodePicker from '../common/NodePicker';
import { formatDuration, formatMeters } from '../../utils/geo';

/**
 * The primary operator action: a call at a scene, not a vehicle with a
 * destination. The unit and the receiving facility are proposed by the system.
 */
export default function NewMissionDialog() {
  const open = useUIStore((s) => s.showMissionDialog);
  const setOpen = useUIStore((s) => s.setShowMissionDialog);
  const nodes = useWorldStore((s) => s.nodes);
  const facilities = useWorldStore((s) => s.facilities);
  const autoApprove = useSettingsStore((s) => s.autoApprove);

  const [service, setService] = useState(SERVICE.MEDICAL);
  const [emergencyClass, setEmergencyClass] = useState('cardiac');
  const [sceneNode, setSceneNode] = useState(() => useWorldStore.getState().nodes[0]?.id ?? null);
  const [priorityOverride, setPriorityOverride] = useState('auto');
  const [note, setNote] = useState('');

  const classes = EMERGENCY_CLASSES[service] || [];
  const cls = findEmergencyClass(service, emergencyClass) || classes[0];
  const priority = priorityOverride === 'auto' ? cls?.priority ?? 2 : Number(priorityOverride);

  // Live preview of what the dispatcher would choose right now.
  const preview = useMemo(() => {
    if (!open || !sceneNode) return null;
    const candidates = rankUnits(service, sceneNode);
    const best = candidates[0] || null;
    let hospital = null;
    if (best && service === SERVICE.MEDICAL) {
      const unit = useWorldStore.getState().getUnit(best.unitId);
      hospital = unit ? chooseHospital(sceneNode, unit) : null;
    }
    return { candidates, best, hospital };
  }, [open, service, sceneNode]);

  if (!open) return null;

  const handleServiceChange = (value) => {
    setService(value);
    const first = (EMERGENCY_CLASSES[value] || [])[0];
    setEmergencyClass(first?.id ?? '');
  };

  const submit = (e) => {
    e.preventDefault();
    const mission = createMission({
      service,
      emergencyClass,
      sceneNode,
      priority: priorityOverride === 'auto' ? undefined : Number(priorityOverride),
      note,
    });
    toast.success(
      autoApprove
        ? `${mission.id} created and auto-dispatched`
        : `${mission.id} created — awaiting dispatch approval`,
    );
    setOpen(false);
    setNote('');
  };

  const sceneName = nodes.find((n) => n.id === sceneNode)?.name ?? sceneNode;

  return (
    <Modal
      title="New mission"
      subtitle="Create an emergency call at a scene — the system proposes the unit and receiving facility"
      onClose={() => setOpen(false)}
      width="max-w-2xl"
      footer={
        <>
          <Button variant="subtle" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button onClick={submit} disabled={!sceneNode || !preview?.best}>
            {autoApprove ? 'Create & dispatch' : 'Create mission'}
          </Button>
        </>
      }
    >
      <form onSubmit={submit} className="grid md:grid-cols-2 gap-5">
        <div className="space-y-3">
          <Field label="Service">
            <div className="grid grid-cols-2 gap-2">
              {[SERVICE.MEDICAL, SERVICE.FIRE].map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => handleServiceChange(s)}
                  className={`px-3 py-2 rounded-lg text-xs font-semibold border transition-colors ${
                    service === s
                      ? 'bg-[#EDE9FE] border-[#7C6FEF] text-[#7C6FEF]'
                      : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  {SERVICE_LABEL[s]}
                </button>
              ))}
            </div>
          </Field>

          <Field label="Emergency class" hint={`On-scene dwell ${cls?.dwell ?? 45}s`}>
            <Select value={emergencyClass} onChange={(e) => setEmergencyClass(e.target.value)}>
              {classes.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.label} (default P{c.priority})
                </option>
              ))}
            </Select>
          </Field>

          <Field label="Scene junction" hint="Search by road name, or click a junction on the operations map.">
            <NodePicker value={sceneNode} onChange={setSceneNode} placeholder="Search a road or junction" />
          </Field>

          <Field label="Priority" hint="Override only when the call warrants it">
            <Select value={priorityOverride} onChange={(e) => setPriorityOverride(e.target.value)}>
              <option value="auto">Automatic — from emergency class</option>
              <option value="1">{PRIORITY_LABEL[1]}</option>
              <option value="2">{PRIORITY_LABEL[2]}</option>
              <option value="3">{PRIORITY_LABEL[3]}</option>
            </Select>
          </Field>

          <Field label="Caller note (optional)">
            <Input value={note} onChange={(e) => setNote(e.target.value)} placeholder="e.g. two casualties, access from north" />
          </Field>
        </div>

        <div className="space-y-3">
          <div className="rounded-xl border border-[#E5E7EB] bg-gray-50/70 p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-gray-400">System proposal</span>
              <Badge tone="bg-[#EDE9FE] text-[#7C6FEF]">P{priority}</Badge>
            </div>

            {!sceneNode ? (
              <p className="text-[11px] text-gray-400 italic py-4">Pick a scene junction to see the dispatch proposal.</p>
            ) : preview?.best ? (
              <>
                <KeyValue label="Scene" value={sceneName} />
                <KeyValue label="Suggested unit" value={preview.best.label} />
                <KeyValue label="Dispatch from" value={preview.best.facilityId} mono />
                <KeyValue label="Leg 1 distance" value={formatMeters(preview.best.distance)} />
                <KeyValue label="Leg 1 ETA" value={formatDuration(preview.best.eta)} />
                {preview.hospital && (
                  <>
                    <KeyValue label="Likely hospital" value={preview.hospital.facility.name} />
                    <KeyValue label="Leg 2 ETA" value={formatDuration(preview.hospital.plan.eta)} />
                  </>
                )}
                {service === SERVICE.FIRE && (
                  <p className="text-[10px] text-gray-500 mt-2 leading-relaxed">
                    Fire response routes Leg 1 only. Return to station is not part of the optimised response.
                  </p>
                )}
              </>
            ) : (
              <p className="text-[11px] text-red-600 font-medium py-4">
                No suitable unit is currently available. The call can still be created — it will queue until a unit frees up.
              </p>
            )}
          </div>

          {preview?.candidates?.length > 1 && (
            <div className="rounded-xl border border-[#E5E7EB] p-3">
              <span className="text-[11px] font-bold uppercase tracking-wider text-gray-400 block mb-2">
                Candidate ranking
              </span>
              <div className="space-y-1">
                {preview.candidates.slice(0, 4).map((c, i) => (
                  <div key={c.unitId} className="flex items-center justify-between text-[11px]">
                    <span className={i === 0 ? 'font-bold text-gray-900' : 'text-gray-600'}>
                      {i + 1}. {c.label}
                    </span>
                    <span className="font-mono text-gray-500">{formatDuration(c.eta)}</span>
                  </div>
                ))}
              </div>
              <p className="text-[9.5px] text-gray-400 mt-2">Ranked by congestion-aware ETA from the unit's facility.</p>
            </div>
          )}

          <p className="text-[10px] text-gray-400 leading-relaxed">
            Hospitals: {facilities.filter((f) => f.type === FACILITY_TYPE.HOSPITAL).length} · Fire stations:{' '}
            {facilities.filter((f) => f.type === FACILITY_TYPE.FIRE_STATION).length}
          </p>
        </div>
      </form>
    </Modal>
  );
}
