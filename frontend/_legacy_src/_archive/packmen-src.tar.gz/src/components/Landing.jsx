import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, TrafficCone, Ambulance, Activity } from 'lucide-react';

const highlights = [
  {
    icon: Ambulance,
    title: 'Mission-based dispatch',
    body: 'Calls at a scene, nearest unit from a hospital or fire station, multi-leg response with on-scene dwell.',
  },
  {
    icon: Activity,
    title: 'Live congestion routing',
    body: 'A* prices every segment against a live congestion index, replanning around blockages and jams.',
  },
  {
    icon: TrafficCone,
    title: 'Green corridor',
    body: 'Signal preemption along a frozen path, with junction contests resolved by priority class.',
  },
];

export default function Landing() {
  return (
    <div className="min-h-screen bg-[#F7F7FB] flex flex-col items-center justify-center relative overflow-hidden px-6 py-12">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#7C6FEF]/10 blur-[100px] rounded-full pointer-events-none" />

      <div className="z-10 flex flex-col items-center text-center max-w-4xl">
        <div className="mb-7 p-4 bg-white rounded-2xl shadow-xl shadow-[#7C6FEF]/10 border border-gray-100">
          <svg width="64" height="64" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="50" cy="50" r="40" fill="#7C6FEF" />
            <path d="M50 50 L90 20 A40 40 0 0 1 90 80 Z" fill="#F7F7FB" />
            <circle cx="50" cy="25" r="5" fill="#F7F7FB" />
          </svg>
        </div>

        <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-3 tracking-tight">Packmen</h1>

        <p className="text-base md:text-lg text-gray-500 mb-2 max-w-xl">
          Smart-Corridor operations console — 5G-URLLC emergency routing, dynamic response to blockages and green-wave signal
          preemption on a live digital twin.
        </p>

        <Link
          to="/operations"
          className="mt-8 flex items-center gap-2 bg-[#7C6FEF] hover:bg-[#6C5FDF] text-white rounded-full px-8 py-3 text-base font-semibold shadow-lg shadow-[#7C6FEF]/25 transition-all hover:scale-105 active:scale-95"
        >
          Open operations console
          <ArrowRight className="w-5 h-5" />
        </Link>

        <div className="grid md:grid-cols-3 gap-4 mt-14 text-left w-full">
          {highlights.map((h) => (
            <div key={h.title} className="bg-white/80 backdrop-blur border border-[#E5E7EB] rounded-xl p-4">
              <h.icon className="w-4 h-4 text-[#7C6FEF] mb-2" />
              <p className="text-[12px] font-bold text-gray-900">{h.title}</p>
              <p className="text-[11px] text-gray-500 mt-1 leading-relaxed">{h.body}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="absolute bottom-6 text-[11px] text-gray-400 font-medium tracking-wide">
        Team Packmen • NIT Silchar • 5G India Hackathon
      </div>
    </div>
  );
}
