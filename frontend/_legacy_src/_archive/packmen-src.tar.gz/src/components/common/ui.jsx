import React from 'react';

/** Small shared primitives so every panel looks like the same product. */

export function Card({ className = '', children, ...rest }) {
  return (
    <div
      className={`bg-white border border-[#E5E7EB] rounded-xl ${className}`}
      {...rest}
    >
      {children}
    </div>
  );
}

export function Panel({ title, subtitle, actions, className = '', bodyClass = '', children }) {
  return (
    <Card className={`flex flex-col overflow-hidden ${className}`}>
      {(title || actions) && (
        <div className="flex items-start justify-between gap-3 px-4 py-3 border-b border-[#E5E7EB] bg-gray-50/70 shrink-0">
          <div className="min-w-0">
            {title && <h3 className="text-sm font-semibold text-gray-900 truncate">{title}</h3>}
            {subtitle && <p className="text-[11px] text-gray-500 mt-0.5">{subtitle}</p>}
          </div>
          {actions && <div className="flex items-center gap-2 shrink-0">{actions}</div>}
        </div>
      )}
      <div className={`flex-1 min-h-0 overflow-y-auto ${bodyClass || 'p-4'}`}>{children}</div>
    </Card>
  );
}

export function Badge({ tone = 'bg-gray-100 text-gray-600', className = '', children }) {
  return (
    <span
      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold whitespace-nowrap ${tone} ${className}`}
    >
      {children}
    </span>
  );
}

export function StatTile({ label, value, hint, icon: Icon, tone = 'bg-gray-100 text-gray-600' }) {
  return (
    <Card className="p-4 flex items-start gap-3 card-hover">
      {Icon && (
        <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${tone}`}>
          <Icon className="w-4.5 h-4.5" style={{ width: 18, height: 18 }} />
        </div>
      )}
      <div className="min-w-0">
        <p className="text-[11px] text-gray-500 font-medium truncate">{label}</p>
        <p className="text-2xl font-semibold text-gray-900 leading-tight tabular-nums">{value}</p>
        {hint && <p className="text-[10px] text-gray-400 mt-0.5 truncate">{hint}</p>}
      </div>
    </Card>
  );
}

export function EmptyState({ icon: Icon, title, hint }) {
  return (
    <div className="h-full flex flex-col items-center justify-center text-center py-10 px-4">
      {Icon && <Icon className="w-7 h-7 text-gray-300 mb-2" />}
      <p className="text-xs font-semibold text-gray-500">{title}</p>
      {hint && <p className="text-[11px] text-gray-400 mt-1 max-w-xs">{hint}</p>}
    </div>
  );
}

export function Meter({ value, tone = 'bg-[#7C6FEF]', height = 'h-1.5' }) {
  const pct = Math.max(0, Math.min(1, value || 0)) * 100;
  return (
    <div className={`w-full ${height} bg-gray-100 rounded-full overflow-hidden`}>
      <div className={`h-full rounded-full transition-all duration-300 ${tone}`} style={{ width: `${pct}%` }} />
    </div>
  );
}

export function Field({ label, hint, children, className = '' }) {
  return (
    <label className={`block ${className}`}>
      <span className="block text-[11px] font-semibold text-gray-600 mb-1">{label}</span>
      {children}
      {hint && <span className="block text-[10px] text-gray-400 mt-1">{hint}</span>}
    </label>
  );
}

const controlClass =
  'w-full px-3 py-2 border border-gray-200 rounded-lg text-xs bg-white focus:ring-2 focus:ring-[#7C6FEF] focus:border-transparent outline-none';

export function Select({ className = '', children, ...rest }) {
  return (
    <select className={`${controlClass} ${className}`} {...rest}>
      {children}
    </select>
  );
}

export function Input({ className = '', ...rest }) {
  return <input className={`${controlClass} ${className}`} {...rest} />;
}

export function Button({ variant = 'primary', className = '', children, ...rest }) {
  const variants = {
    primary: 'bg-[#7C6FEF] hover:bg-[#6C5FDF] text-white shadow-sm',
    ghost: 'bg-white border border-[#E5E7EB] text-gray-700 hover:bg-gray-50',
    subtle: 'bg-gray-100 text-gray-700 hover:bg-gray-200',
    danger: 'bg-red-50 text-red-600 border border-red-200 hover:bg-red-100',
    success: 'bg-green-50 text-green-700 border border-green-200 hover:bg-green-100',
  };
  return (
    <button
      className={`inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors disabled:opacity-40 disabled:cursor-not-allowed ${variants[variant]} ${className}`}
      {...rest}
    >
      {children}
    </button>
  );
}

export function Modal({ title, subtitle, onClose, footer, width = 'max-w-lg', children }) {
  return (
    <div className="fixed inset-0 bg-black/50 z-[2000] flex items-center justify-center p-4 animate-fade-in">
      <div className={`bg-white rounded-xl shadow-2xl w-full ${width} max-h-[90vh] flex flex-col overflow-hidden`}>
        <div className="px-5 py-4 border-b border-[#E5E7EB] flex items-start justify-between gap-4 shrink-0">
          <div>
            <h2 className="text-base font-semibold text-gray-900">{title}</h2>
            {subtitle && <p className="text-[11px] text-gray-500 mt-0.5">{subtitle}</p>}
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-700 text-2xl leading-none -mt-1"
            aria-label="Close"
          >
            &times;
          </button>
        </div>
        <div className="flex-1 min-h-0 overflow-y-auto p-5">{children}</div>
        {footer && (
          <div className="px-5 py-3 border-t border-[#E5E7EB] bg-gray-50 flex justify-end gap-2 shrink-0">
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}

export function KeyValue({ label, value, mono = false }) {
  return (
    <div className="flex items-baseline justify-between gap-3 py-1">
      <span className="text-[11px] text-gray-500 shrink-0">{label}</span>
      <span className={`text-[11px] font-semibold text-gray-800 text-right truncate ${mono ? 'font-mono' : ''}`}>
        {value}
      </span>
    </div>
  );
}
