import React, { useMemo, useState } from 'react';
import { CircleMarker, Polyline, Tooltip, Popup, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import { toast } from 'sonner';

import useWorldStore from '../../store/useWorldStore';
import useSettingsStore from '../../store/useSettingsStore';
import { injectDisaster, clearDisasterAtNode } from '../../engine/disasters';
import { createMission } from '../../engine/missions';
import { NODE_STATUS, LIGHT_STATE, LIGHT_STATE_LABEL, SERVICE } from '../../domain/constants';
import { roadWeight } from '../../data/network';
import { Button, KeyValue, Meter } from '../common/ui';

/**
 * Roads, junctions and the congestion overlay.
 *
 * Split out of the map and memoised on purpose: unit positions update ten times
 * a second, and the road network does not need to re-render with them. This
 * component subscribes only to the slow-moving parts of the world.
 *
 * On a real city network there are hundreds of junctions, so plain junction dots
 * only appear once you zoom in. Junctions that matter — blocked, preempted,
 * congested, or carrying a facility — are always drawn.
 */
function nodeAppearance(node, light, isBlocked) {
  if (isBlocked) return { fill: '#DC2626', stroke: '#991B1B', radius: 9, opacity: 0.95 };
  if (light && (light.state === LIGHT_STATE.PREEMPT_GREEN || light.state === LIGHT_STATE.RELEASING)) {
    return { fill: '#22C55E', stroke: '#15803D', radius: 8, opacity: 0.95 };
  }
  if (node.status === NODE_STATUS.CONGESTED) return { fill: '#EA580C', stroke: '#9A3412', radius: 7, opacity: 0.9 };
  return { fill: '#64748B', stroke: '#334155', radius: 4.5, opacity: 0.65 };
}

const roadColor = (roadClass) => {
  if (['motorway', 'trunk', 'motorway_link', 'trunk_link'].includes(roadClass)) return '#F59E0B';
  if (['primary', 'primary_link'].includes(roadClass)) return '#FBBF24';
  if (['secondary', 'secondary_link'].includes(roadClass)) return '#CBD5E1';
  return '#D8DEE7';
};

function NodePopup({ node, isBlocked, light }) {
  // Read the fleet on demand rather than subscribing — this only renders when
  // the operator actually opens a junction.
  const units = useWorldStore.getState().units;
  const facility = useWorldStore.getState().facilities.find((f) => f.node === node.id);
  const unitsHere = units.filter((u) => u.node === node.id || u.route?.path.includes(node.id));
  const congestionPct = Math.round((node.congestion || 0) * 100);

  return (
    <div className="min-w-[236px]">
      <div className="flex items-start justify-between gap-2 border-b pb-1.5 mb-2">
        <span className="text-xs font-bold text-gray-900 leading-tight">{node.name}</span>
        <span className="text-[10px] font-mono text-gray-400 shrink-0">{node.id}</span>
      </div>

      <div className="mb-2">
        {isBlocked ? (
          <span className="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-100 text-red-700">
            Blocked — disaster
          </span>
        ) : light ? (
          <span className="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold bg-green-100 text-green-700">
            {LIGHT_STATE_LABEL[light.state]}
            {light.servingUnitId ? ` · ${light.servingUnitId}` : ''}
          </span>
        ) : (
          <span className="inline-flex px-2 py-0.5 rounded-full text-[10px] font-semibold bg-gray-100 text-gray-600">
            Clear intersection
          </span>
        )}
      </div>

      <div className="mb-2">
        <div className="flex justify-between text-[10px] text-gray-500 mb-1">
          <span>Live congestion index c_v</span>
          <span className="font-bold text-gray-800">{congestionPct}%</span>
        </div>
        <Meter
          value={node.congestion}
          tone={congestionPct > 60 ? 'bg-orange-500' : congestionPct > 35 ? 'bg-amber-400' : 'bg-green-500'}
        />
        <p className="text-[9px] text-gray-400 mt-1">
          {node.rawDensity?.toFixed(1) ?? 0} civilian agents nearby · EMA smoothed
        </p>
      </div>

      <KeyValue label="Roads meeting here" value={node.degree ?? '—'} />
      <KeyValue label="Coordinates" value={`${node.lat.toFixed(5)}, ${node.lng.toFixed(5)}`} mono />
      {facility && <KeyValue label="Facility" value={facility.name} />}
      <KeyValue label="Units on / through" value={unitsHere.length || '—'} />
      {unitsHere.length > 0 && (
        <div className="flex flex-wrap gap-1 mt-1 mb-1">
          {unitsHere.map((u) => (
            <span key={u.id} className="px-1.5 py-0.5 rounded bg-gray-100 text-gray-700 text-[10px] font-medium">
              {u.id}
            </span>
          ))}
        </div>
      )}

      <div className="mt-3 space-y-1.5 border-t pt-2">
        {isBlocked ? (
          <Button variant="success" className="w-full" onClick={() => clearDisasterAtNode(node.id)}>
            Clear disaster from this junction
          </Button>
        ) : (
          <Button
            variant="danger"
            className="w-full"
            onClick={() => {
              const created = injectDisaster({ node: node.id, type: 'flood', severity: 0.85 });
              if (created) toast.error(`Disaster injected at ${node.name}`);
            }}
          >
            Inject disaster at this junction
          </Button>
        )}
        <Button
          variant="ghost"
          className="w-full"
          onClick={() => {
            createMission({ service: SERVICE.MEDICAL, emergencyClass: 'rta', sceneNode: node.id });
            toast.success(`Medical call created at ${node.name}`);
          }}
        >
          Create medical call here
        </Button>
      </div>
    </div>
  );
}

function NodesLayer() {
  const nodes = useWorldStore((s) => s.nodes);
  const edges = useWorldStore((s) => s.edges);
  const disasters = useWorldStore((s) => s.disasters);
  const lights = useWorldStore((s) => s.lights);
  const facilities = useWorldStore((s) => s.facilities);

  const showCongestion = useSettingsStore((s) => s.showCongestionOverlay);
  const showRoads = useSettingsStore((s) => s.showGridEdges);
  const alwaysShowJunctions = useSettingsStore((s) => s.showAllJunctions);

  const [zoom, setZoom] = useState(null);
  const map = useMapEvents({ zoomend: () => setZoom(map.getZoom()) });
  const currentZoom = zoom ?? map.getZoom();

  const blocked = useMemo(() => new Set(disasters.map((d) => d.node)), [disasters]);
  const facilityNodes = useMemo(() => new Set(facilities.map((f) => f.node)), [facilities]);

  /** Roads are static, so their geometry is built once. */
  const roads = useMemo(
    () =>
      showRoads
        ? edges.map((e) => ({
            id: `${e.from}|${e.to}`,
            positions: e.geometry ?? [],
            color: roadColor(e.roadClass),
            weight: roadWeight(e.roadClass),
            name: e.roadName,
          }))
        : [],
    [edges, showRoads],
  );

  const showAll = alwaysShowJunctions || currentZoom >= 15;

  return (
    <>
      {roads.map((road) =>
        road.positions.length > 1 ? (
          <Polyline
            key={road.id}
            positions={road.positions}
            pathOptions={{
              color: road.color,
              weight: road.weight,
              opacity: 0.75,
              interactive: false,
              lineCap: 'round',
              lineJoin: 'round',
            }}
          />
        ) : null,
      )}

      {nodes.map((node) => {
        const isBlocked = blocked.has(node.id) || node.status === NODE_STATUS.BLOCKED;
        const light = lights[node.id];
        const notable =
          isBlocked ||
          Boolean(light) ||
          node.status === NODE_STATUS.CONGESTED ||
          facilityNodes.has(node.id);

        if (!notable && !showAll) return null;

        const look = nodeAppearance(node, light, isBlocked);

        return (
          <React.Fragment key={node.id}>
            {showCongestion && node.congestion > 0.3 && !isBlocked && (
              <CircleMarker
                center={[node.lat, node.lng]}
                radius={8 + node.congestion * 18}
                pathOptions={{
                  color: 'transparent',
                  fillColor: node.congestion > 0.6 ? '#F97316' : '#FBBF24',
                  fillOpacity: 0.08 + node.congestion * 0.18,
                  interactive: false,
                }}
              />
            )}

            {light && light.state === LIGHT_STATE.PREEMPT_GREEN && (
              <CircleMarker
                center={[node.lat, node.lng]}
                radius={15}
                pathOptions={{
                  color: '#22C55E',
                  fillColor: '#22C55E',
                  fillOpacity: 0.2,
                  weight: 2,
                  dashArray: '3, 3',
                  interactive: false,
                }}
              />
            )}

            <CircleMarker
              center={[node.lat, node.lng]}
              radius={look.radius}
              pathOptions={{ color: look.stroke, fillColor: look.fill, fillOpacity: look.opacity, weight: 1.5 }}
              eventHandlers={{ click: (e) => L.DomEvent.stopPropagation(e) }}
            >
              <Tooltip direction="top" offset={[0, -8]} opacity={0.95}>
                <div className="text-[11px] font-semibold">
                  {node.name}
                  <span className="block text-[9px] text-gray-400 font-mono">
                    c = {node.congestion.toFixed(2)} · click to inspect
                  </span>
                </div>
              </Tooltip>

              <Popup>
                <NodePopup node={node} isBlocked={isBlocked} light={light} />
              </Popup>
            </CircleMarker>
          </React.Fragment>
        );
      })}
    </>
  );
}

export default React.memo(NodesLayer);
