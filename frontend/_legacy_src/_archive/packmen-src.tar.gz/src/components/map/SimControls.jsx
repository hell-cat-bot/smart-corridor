import React from 'react';
import { Play, Pause, RotateCcw, SkipForward } from 'lucide-react';
import useWorldStore from '../../store/useWorldStore';
import { toggleSim, setSpeed, stepSeconds, resetWorld } from '../../engine/simulation';
import { formatSimClock } from '../../utils/geo';

/**
 * Simulation transport. The clock is real simulation time, not a scripted
 * timeline — playback speed only changes how fast that clock advances.
 */
export default function SimControls() {
  const running = useWorldStore((s) => s.running);
  const speed = useWorldStore((s) => s.speed);
  const simTime = useWorldStore((s) => s.simTime);

  return (
    <div className="absolute bottom-5 left-1/2 -translate-x-1/2 z-[1000] bg-white/92 backdrop-blur-md border border-[#E5E7EB] shadow-lg rounded-full px-4 py-2 flex items-center gap-4">
      <button
        onClick={toggleSim}
        className="w-9 h-9 rounded-full bg-[#7C6FEF] text-white flex items-center justify-center hover:bg-[#6859eb] transition-all shadow-sm active:scale-95"
        title={running ? 'Pause simulation' : 'Run simulation'}
      >
        {running ? <Pause className="w-4 h-4" fill="currentColor" /> : <Play className="w-4 h-4 ml-0.5" fill="currentColor" />}
      </button>

      <button
        onClick={() => stepSeconds(1)}
        disabled={running}
        className="w-8 h-8 rounded-full text-gray-500 hover:bg-gray-100 flex items-center justify-center disabled:opacity-30"
        title="Step 1 simulation second"
      >
        <SkipForward className="w-4 h-4" />
      </button>

      <div className="flex items-center gap-1 bg-gray-50 p-0.5 rounded-full border border-gray-200">
        {[1, 2, 4, 8].map((s) => (
          <button
            key={s}
            onClick={() => setSpeed(s)}
            className={`w-8 h-7 rounded-full text-[11px] font-bold transition-colors ${
              speed === s ? 'bg-[#7C6FEF] text-white' : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            {s}x
          </button>
        ))}
      </div>

      <div className="flex items-center gap-2 px-1">
        <span className="text-[10px] uppercase tracking-wider font-bold text-gray-400">Sim clock</span>
        <span className="text-xs font-mono font-bold text-gray-800 tabular-nums w-[70px]">{formatSimClock(simTime)}</span>
        <span className={`w-1.5 h-1.5 rounded-full ${running ? 'bg-green-500 animate-pulse' : 'bg-gray-300'}`} />
      </div>

      <button
        onClick={resetWorld}
        className="text-gray-400 hover:text-red-500 p-2 rounded-full hover:bg-red-50 transition-colors"
        title="Reset all system state"
      >
        <RotateCcw className="w-4 h-4" />
      </button>
    </div>
  );
}
