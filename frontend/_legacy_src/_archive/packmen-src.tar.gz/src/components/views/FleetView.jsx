import React from 'react';
import { Building2, Truck } from 'lucide-react';
import useWorldStore from '../../store/useWorldStore';
import useUIStore from '../../store/useUIStore';
import { UnitCard } from '../panels/UnitsPanel';
import { Panel, Badge, KeyValue } from '../common/ui';
import { FACILITY_TYPE, UNIT_STATUS, UNIT_TYPE } from '../../domain/constants';

export default function FleetView() {
  const units = useWorldStore((s) => s.units);
  const facilities = useWorldStore((s) => s.facilities);
  const nodes = useWorldStore((s) => s.nodes);
  const selectedUnitId = useUIStore((s) => s.selectedUnitId);
  const setSelectedUnitId = useUIStore((s) => s.setSelectedUnitId);

  const hospitals = facilities.filter((f) => f.type === FACILITY_TYPE.HOSPITAL);
  const stations = facilities.filter((f) => f.type === FACILITY_TYPE.FIRE_STATION);

  const FacilityCard = ({ facility }) => {
    const based = units.filter((u) => u.baseFacilityId === facility.id);
    const available = based.filter((u) => u.status === UNIT_STATUS.AVAILABLE).length;
    const node = nodes.find((n) => n.id === facility.node);
    const isHospital = facility.type === FACILITY_TYPE.HOSPITAL;

    return (
      <div className="rounded-lg border border-gray-100 bg-gray-50/60 p-3">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <p className="text-[11.5px] font-bold text-gray-900 truncate">{facility.name}</p>
            <p className="text-[10px] text-gray-500">{node?.name ?? facility.node}</p>
          </div>
          <Badge tone={isHospital ? 'bg-teal-50 text-teal-700' : 'bg-amber-50 text-amber-700'}>
            {isHospital ? 'Hospital' : 'Fire station'}
          </Badge>
        </div>
        <div className="mt-2">
          <KeyValue label={isHospital ? 'Beds' : 'Bays'} value={facility.beds ?? facility.bays} />
          <KeyValue label="Units based here" value={`${available} available / ${based.length}`} />
        </div>
        <div className="flex flex-wrap gap-1 mt-1.5">
          {based.map((u) => (
            <span key={u.id} className="px-1.5 py-0.5 rounded bg-white border border-gray-200 text-gray-600 text-[9.5px] font-mono">
              {u.id}
            </span>
          ))}
          {based.length === 0 && <span className="text-[10px] text-gray-400 italic">No units currently based here</span>}
        </div>
      </div>
    );
  };

  const ambulances = units.filter((u) => u.type === UNIT_TYPE.AMBULANCE);
  const engines = units.filter((u) => u.type === UNIT_TYPE.FIRETRUCK);

  return (
    <div className="flex-1 overflow-y-auto p-5 min-h-0">
      <div className="grid xl:grid-cols-3 gap-4">
        <Panel
          title="Ambulance fleet"
          subtitle={`${ambulances.filter((u) => u.status === UNIT_STATUS.AVAILABLE).length} of ${ambulances.length} available`}
          actions={<Truck className="w-4 h-4 text-gray-300" />}
          className="min-h-[300px]"
        >
          <div className="space-y-1.5">
            {ambulances.map((u) => (
              <UnitCard key={u.id} unit={u} selected={selectedUnitId === u.id} onSelect={() => setSelectedUnitId(u.id)} />
            ))}
          </div>
        </Panel>

        <Panel
          title="Fire fleet"
          subtitle={`${engines.filter((u) => u.status === UNIT_STATUS.AVAILABLE).length} of ${engines.length} available`}
          actions={<Truck className="w-4 h-4 text-gray-300" />}
          className="min-h-[300px]"
        >
          <div className="space-y-1.5">
            {engines.map((u) => (
              <UnitCard key={u.id} unit={u} selected={selectedUnitId === u.id} onSelect={() => setSelectedUnitId(u.id)} />
            ))}
          </div>
        </Panel>

        <Panel
          title="Facilities"
          subtitle="Placement and availability anchors for dispatch"
          actions={<Building2 className="w-4 h-4 text-gray-300" />}
          className="min-h-[300px]"
        >
          <div className="space-y-2">
            {[...hospitals, ...stations].map((f) => (
              <FacilityCard key={f.id} facility={f} />
            ))}
          </div>
        </Panel>
      </div>
    </div>
  );
}
