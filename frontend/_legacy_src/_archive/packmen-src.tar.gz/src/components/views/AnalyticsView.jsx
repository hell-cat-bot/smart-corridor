import React, { useMemo } from 'react';
import { Clock, Gauge, GitBranch, Zap, CheckCircle2, AlertTriangle, Activity, Radio } from 'lucide-react';
import useWorldStore from '../../store/useWorldStore';
import { Panel, StatTile, KeyValue } from '../common/ui';
import { LineChart, BarChart, RankedBars } from '../common/charts';
import { formatDuration } from '../../utils/geo';
import {
  MISSION_STATUS,
  MISSION_STATUS_LABEL,
  ACTIVE_MISSION_STATUSES,
  NODE_STATUS,
  UNIT_STATUS,
} from '../../domain/constants';

const mean = (arr) => (arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : null);

export default function AnalyticsView() {
  const missions = useWorldStore((s) => s.missions);
  const units = useWorldStore((s) => s.units);
  const nodes = useWorldStore((s) => s.nodes);
  const lights = useWorldStore((s) => s.lights);
  const disasters = useWorldStore((s) => s.disasters);
  const metrics = useWorldStore((s) => s.metrics);
  const history = useWorldStore((s) => s.congestionHistory);
  const simTime = useWorldStore((s) => s.simTime);

  const responded = missions.filter((m) => m.onSceneAt != null);
  const completed = missions.filter((m) => m.status === MISSION_STATUS.COMPLETED);
  const avgResponse = mean(responded.map((m) => m.onSceneAt - m.createdAt));
  const efficiency = mean(metrics.efficiencySamples);
  const meanCongestion = nodes.length ? mean(nodes.map((n) => n.congestion)) : 0;

  const responseSeries = useMemo(
    () =>
      responded
        .slice()
        .sort((a, b) => a.createdAt - b.createdAt)
        .slice(-14)
        .map((m) => ({
          label: m.id.replace('M-', ''),
          value: m.onSceneAt - m.createdAt,
          sub: `${m.id} · ${m.emergencyLabel}`,
        })),
    [responded],
  );

  const unitLoad = useMemo(() => {
    const max = Math.max(1, ...units.map((u) => u.missionsCompleted));
    return units
      .slice()
      .sort((a, b) => b.missionsCompleted - a.missionsCompleted)
      .map((u) => ({
        label: u.label,
        value: u.missionsCompleted / max,
        caption: `${u.missionsCompleted} mission(s) · ${u.replanCount} replan(s) · ${u.status}`,
      }));
  }, [units]);

  const byStatus = Object.values(MISSION_STATUS).map((status) => ({
    status,
    count: missions.filter((m) => m.status === status).length,
  }));

  const tiles = [
    {
      label: 'Average response time',
      value: avgResponse == null ? '—' : formatDuration(avgResponse),
      hint: `${responded.length} mission(s) reached a scene`,
      icon: Clock,
      tone: 'bg-[#DCFCE7] text-[#16A34A]',
    },
    {
      label: 'Corridor efficiency index',
      value: efficiency == null ? '—' : `${Math.round(efficiency * 100)}%`,
      hint: 'free-flow time ÷ actual leg time',
      icon: Gauge,
      tone: 'bg-[#EDE9FE] text-[#7C6FEF]',
    },
    {
      label: 'Rerouted legs',
      value: metrics.replans,
      hint: `${metrics.blockageReplans} blockage · ${metrics.congestionReplans} congestion`,
      icon: GitBranch,
      tone: 'bg-[#DBEAFE] text-[#2563EB]',
    },
    {
      label: 'Active preemption nodes',
      value: Object.keys(lights).length,
      hint: `${metrics.preemptionsGranted} grant(s) this session`,
      icon: Zap,
      tone: 'bg-[#DCFCE7] text-[#16A34A]',
    },
    {
      label: 'Missions completed',
      value: metrics.missionsCompleted,
      hint: `${missions.filter((m) => ACTIVE_MISSION_STATUSES.includes(m.status)).length} still running`,
      icon: CheckCircle2,
      tone: 'bg-[#DCFCE7] text-[#16A34A]',
    },
    {
      label: 'Unserved requests',
      value: metrics.unservedRequests,
      hint: 'no suitable unit was free at call time',
      icon: AlertTriangle,
      tone: 'bg-[#FEE2E2] text-[#DC2626]',
    },
    {
      label: 'Mean congestion index',
      value: `${Math.round((meanCongestion ?? 0) * 100)}%`,
      hint: `${nodes.filter((n) => n.status === NODE_STATUS.CONGESTED).length} junction(s) above threshold`,
      icon: Activity,
      tone: 'bg-[#FEF3C7] text-[#D97706]',
    },
    {
      label: 'Junction conflicts',
      value: metrics.conflictsResolved,
      hint: 'resolved by priority, ETA and request order',
      icon: Radio,
      tone: 'bg-fuchsia-50 text-fuchsia-700',
    },
  ];

  return (
    <div className="flex-1 overflow-y-auto p-5 space-y-4 min-h-0">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {tiles.map((t) => (
          <StatTile key={t.label} {...t} />
        ))}
      </div>

      <div className="grid xl:grid-cols-2 gap-4">
        <Panel
          title="Mean congestion index over simulation time"
          subtitle="The live signal A* prices — sampled every 5 simulation seconds"
        >
          <LineChart
            data={history.map((h) => ({ x: h.t, y: h.mean * 100 }))}
            height={170}
            yLabel="%"
            formatY={(v) => `${Math.round(v)}`}
            formatX={(v) => `T+${Math.round(v)}s`}
          />
        </Panel>

        <Panel title="Response time by mission" subtitle="Call created to unit on scene, most recent 14 missions">
          <BarChart data={responseSeries} height={170} formatValue={(v) => `${Math.round(v)}`} unit="s" />
        </Panel>

        <Panel title="Unit workload" subtitle="Missions completed per unit, relative to the busiest">
          <RankedBars data={unitLoad} formatValue={(v) => `${Math.round(v * 100)}%`} />
        </Panel>

        <Panel title="System summary" subtitle="Current world state">
          <div className="grid sm:grid-cols-2 gap-x-6">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1">Missions</p>
              {byStatus.map((s) => (
                <KeyValue key={s.status} label={MISSION_STATUS_LABEL[s.status]} value={s.count} />
              ))}
            </div>
            <div>
              <p className="text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1">Network & fleet</p>
              <KeyValue label="Simulation time" value={formatDuration(simTime)} />
              <KeyValue label="Junctions" value={nodes.length} />
              <KeyValue label="Blocked junctions" value={disasters.length} />
              <KeyValue label="Units available" value={units.filter((u) => u.status === UNIT_STATUS.AVAILABLE).length} />
              <KeyValue label="Units on task" value={units.filter((u) => u.status !== UNIT_STATUS.AVAILABLE).length} />
              <KeyValue label="Completed legs measured" value={metrics.efficiencySamples.length} />
            </div>
          </div>
          <p className="text-[10px] text-gray-400 mt-3 leading-relaxed">
            Corridor efficiency compares each completed leg's actual duration against its free-flow duration on the same path, so
            100% means the corridor delivered the unit as if the network were empty.
          </p>
        </Panel>
      </div>
    </div>
  );
}
