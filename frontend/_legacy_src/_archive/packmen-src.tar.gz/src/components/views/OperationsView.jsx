import React from 'react';
import { Info } from 'lucide-react';
import useWorldStore from '../../store/useWorldStore';
import StatCards from '../layout/StatCards';
import BottomPanel from '../layout/BottomPanel';
import OperationsMap from '../map/OperationsMap';
import SimControls from '../map/SimControls';
import UnitsPanel from '../panels/UnitsPanel';

export default function OperationsView() {
  const isPlaceholder = useWorldStore((s) => s.isPlaceholderNetwork);

  return (
    <div className="flex-1 flex flex-col overflow-hidden min-h-0">
      {isPlaceholder && (
        <div className="mx-5 mt-3 flex items-start gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 shrink-0">
          <Info className="w-3.5 h-3.5 text-amber-600 mt-0.5 shrink-0" />
          <p className="text-[11px] text-amber-800 leading-relaxed">
            Running on the placeholder network. For real Ghaziabad roads — with vehicles following actual road geometry — run{' '}
            <code className="font-mono bg-white/70 px-1 py-0.5 rounded border border-amber-200">
              node scripts/fetch-osm-network.mjs
            </code>{' '}
            once, then restart the dev server.
          </p>
        </div>
      )}

      <div className="px-5 pt-4 shrink-0">
        <StatCards />
      </div>

      <div className="flex-1 flex px-5 py-4 gap-4 overflow-hidden min-h-0">
        <UnitsPanel />
        <div className="flex-1 relative rounded-xl overflow-hidden border border-[#E5E7EB] min-h-[320px]">
          <OperationsMap />
          <SimControls />
        </div>
      </div>

      <BottomPanel />
    </div>
  );
}
