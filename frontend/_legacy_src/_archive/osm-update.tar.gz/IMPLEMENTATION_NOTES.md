# Smart-Corridor dashboard — Part B implementation notes

This build implements the web side of *04_Current_State_and_Planned_Improvements*.
Everything in Part B is in except **B.4 (ML / vision channel)**, which was
explicitly out of scope for now.

Run it the way you always have:

```bash
cd frontend
npm run dev
```

No new dependencies were added.

---

## Before your first run: get the real road network

The map runs on a real OpenStreetMap road network for **central Ghaziabad**.
That data is fetched once, on your machine, and then baked into the project:

```bash
cd frontend
npm run fetch:network        # or: node scripts/fetch-osm-network.mjs
npm run dev
```

The script needs internet and Node 18+, nothing else. It downloads the drivable
roads for the bounding box, reduces them to a junction graph that keeps the real
road polyline between junctions, snaps hospitals and fire stations from OSM onto
it, and writes `src/data/network.json`. Nothing queries the internet at runtime
afterwards, so a flaky network on demo day cannot break the map.

Until you run it, the app boots on a small placeholder lattice and shows a banner
on the Operations view saying so.

Useful options:

```bash
node scripts/fetch-osm-network.mjs --residential          # denser street grid
node scripts/fetch-osm-network.mjs --max-nodes=1400       # allow a bigger graph
node scripts/fetch-osm-network.mjs --bbox=28.60,77.30,28.68,77.40 --name="Indirapuram"
```

### If Overpass is rate-limited (HTTP 429)

429 means the public mirrors are out of query slots, not that anything is wrong
with the query. The script already rotates through five independent mirrors and
backs off across four rounds, so most of the time it just works. If it still
fails:

```bash
node scripts/fetch-osm-network.mjs --status      # who has a free slot, and when
```

And the path that can never be rate-limited — export the data yourself:

```bash
node scripts/fetch-osm-network.mjs --print-query
#  1. paste each query at https://overpass-turbo.eu and press Run
#  2. Export > raw OSM data, saving roads.json and places.json
node scripts/fetch-osm-network.mjs --from-file=roads.json --places-file=places.json
```

`--from-file` never touches the network; it runs exactly the same graph
extraction on data you supply.

### What "real roads" changes

* Vehicles drive the **actual road polyline**, curves included, instead of
  cutting in a straight line between junctions.
* Segment cost uses the measured along-the-road length, so distances and ETAs are
  real distances.
* Junctions are named after the roads that meet there (`GT Road / Hapur Road`),
  and the junction pickers in New Mission, Inject Disaster and the corridor
  builder are searchable by road name rather than dropdowns of every node.
* Hospitals and fire stations come from OSM where they are tagged; where the
  extract is thin, the script tops up with well-spread synthetic ones (flagged
  `synthetic: true` in the file) so the fleet is always usable.
* On a city-scale network only *notable* junctions are drawn by default —
  blocked, preempted, congested, or carrying a facility. Everything else appears
  from zoom 15, or via **Settings → Show every junction**.

---

## What changed at a glance

The old model was *vehicle → destination → one path*, driven by a scripted
17-second timeline (`mockTimeline.js`). That is gone. The system now runs a real
tick-based simulation clock over a single shared world state, and the operator's
primary action is **New mission**, not **Add vehicle**.

Superseded files were moved to `frontend/_legacy_src/` rather than deleted, so
you can still read the old implementations. Nothing imports them.

---

## B.1 — Mission-based emergency flow

* `src/engine/missions.js` owns the whole lifecycle.
* Facilities are first-class: 3 hospitals and 2 fire stations seeded on the grid
  (`src/data/worldSeed.js`), each with units based there.
* **Medical**: call at scene → suggested unit ranked by congestion-aware ETA →
  operator approves → LEG 1 to scene → `ON_SCENE` dwell (per emergency class) →
  LEG 2 replanned fresh to the chosen hospital → complete, unit available at that
  hospital.
* **Fire**: call → LEG 1 → dwell → primary response complete. The return to
  station happens but is deliberately *not* an optimised response leg (it is
  planned with α = 0, i.e. plain distance).
* Hospital choice prefers the unit's home hospital when it is within 10% of the
  nearest feasible one; the alternatives considered are written to the log.
* Approve/dispatch stays in the loop unless **auto-approve** is switched on in
  Settings (demo mode).
* Pending calls are re-evaluated as units free up.

## B.2 — Live congestion index driving A*

* `src/engine/congestion.js`. A background civilian population (default 45
  agents, adjustable) circulates on the grid. Node density → congestion index
  `c_v` ∈ [0,1], smoothed with an EMA. Junction status uses hysteresis
  (enters "congested" above 0.60, leaves below 0.45) so badges do not flicker.
* Segment cost, in `src/utils/pathfinding.js`:

  ```
  W(u,v) = d(u,v) × (1 + α · c_v · ω_priority)
  ```

  `ω` is per vehicle class and controls how strongly congestion penalises that
  class — emergency units are partly shielded because preemption clears their
  approach. Both α and ω are sliders in Settings.
* Blocked (disaster) junctions are removed from the graph entirely — infinite
  cost, independent of congestion.
* **Replanning**: a blockage on the active leg replans immediately; congestion
  replans are gated by a cooldown (default 10 s per unit) *and* a minimum ETA
  improvement (default 12%), so paths do not thrash. Solid active path + dashed
  previous path is retained on the map.

## B.3 — Green Corridor view

* Separate view (`/corridor`), `src/engine/corridor.js` + `CorridorMap.jsx`.
* Paths are planned once at session start and then **frozen**.
* Traffic lights sit on every junction along the paths and run a normal cycle
  when nobody is asking for them.
* A vehicle requests a green on every signalised junction within the approach
  radius (default 260 m). On grant the light goes to preempt-green; after the
  vehicle clears it, the light releases back to the normal cycle.
* **Multi-vehicle arbitration**: priority class → ETA to the junction → request
  order → deterministic unit-id tie-break. The loser physically holds at the stop
  line. Every request, grant, hold, release and contest is recorded in the
  session timeline *and* the structured log.
* Three presets ship with it, including a two-vehicle and a three-vehicle
  scenario built to force contested junctions.

## B.5 — Structured, separated logs

* `src/store/useLogStore.js` + the Logs view.
* Categories: mission, dispatch, routing, congestion, disaster, signal,
  conflict, simulation.
* Every record carries wall-clock time, **simulation time**, category, severity,
  entity references (mission / unit / node / facility) and the structured data
  behind the decision — e.g. the full candidate ranking for a dispatch, or the
  contenders and tie-break rule for a junction contest.
* Filter by category and severity, full-text search across messages, refs and
  payloads, expand any row to see the raw JSON, export the whole log.
* Congestion is high-volume, so it is *sampled* into the log every 20 simulation
  seconds rather than logged on every change.

## B.6 — Supporting platform changes

| Area | Where |
|---|---|
| Domain model (missions, legs, units, facilities, lights, corridor sessions) | `src/domain/constants.js`, `src/store/*` |
| Simulation clock — tick based, 10 Hz, 1×–8× | `src/engine/simulation.js` |
| Single shared world state | `src/store/useWorldStore.js` |
| Priority usage — dispatch ordering and junction tie-break | `missions.js`, `preemption.js` |
| Demo seeding — facilities, units, scenario presets | `src/data/worldSeed.js`, `src/engine/scenarios.js` |

Decision logic deliberately lives in `src/engine/*`; the stores hold state and
primitive setters only, so there is one place where dispatch, routing and
preemption rules are defined.

## B.7 — Information architecture

```
Operations       map · missions · units · disasters · live A* · congestion
Green Corridor   frozen path · traffic lights · preemption · conflicts
Missions         dispatch queue · active · history · route comparison
Fleet            units and facilities
Disasters        active blockages
Analytics        response and corridor metrics
Logs             structured, filterable
Settings         calibration · demo scenarios · reset
```

## Retained from Part A

6×6 grid over the OSM basemap, node status colours, disaster injection from the
map or the top bar, the four disaster types, dashed original route after a
reroute, dispatch approval, route comparison (now A* vs Dijkstra *and* A* vs
pre-replan path), analytics shell, activity logging, settings and full reset.

---

## Not implemented (by request)

**B.4 — ML / vision channel.** No ML view, no observation intake, no inference.
The seam it plugs into already exists: a vision result would only need to write
a node's congestion index and, for hazard classes, add the node to the blocked
set — both of which are already the inputs routing consumes. Accident detections
would call `createMission()` exactly as the operator's New Mission dialog does.

---

## Verification performed

Package installation was unavailable in the environment this was written in, so
verification was done statically and headlessly rather than by running Vite:

* Every source file transpiled with the TypeScript compiler (JSX-aware) —
  0 syntax errors across 51 files.
* Every relative import resolved and every named binding checked against the
  target module's exports — 0 unresolved.
* Rules-of-hooks pass (no hook after an early return, no conditional hooks).
* Zustand selector audit — no selector returns a freshly built array/object
  (which would re-render on every tick).
* **Headless engine test** driving the real simulation with a stubbed clock:
  medical mission through both legs, fire mission single-leg completion,
  blockage-driven replanning with the original path retained, dispatch queueing
  when the fleet is exhausted, corridor preemption with contested junctions and
  a vehicle actually held, log category coverage, and numeric sanity on unit
  positions and congestion bounds.
* The same suite run against **three different networks**: the shipped
  placeholder, a synthetic city-scale network (712 junctions, 1147 curved
  segments, dead ends and a genuine articulation point), and a network produced
  by the fetch script itself from a stubbed Overpass response. All pass on all
  three; the whole suite runs in about five seconds at city scale.
* **The fetch script tested end to end** against a synthetic Overpass payload
  shaped like real OSM data — shared crossing nodes, per-point way geometry, a
  dead-end spur and a disconnected island. Verified: intersections detected from
  shared node ids, ways split at them, pass-through junctions merged, the island
  dropped by largest-connected-component, junction names composed from the
  crossing road names, OSM hospitals and fire stations snapped on with synthetic
  top-ups, and every segment's geometry endpoints matching its junctions with no
  duplicates or dangling references.

Two behaviours worth knowing, both confirmed correct rather than bugs:

* A blockage on a junction the vehicle has **already driven past** does not
  trigger a replan. Only the part of the route still ahead is checked.
* If a blockage cuts the destination off entirely (a bridge, an articulation
  point), the unit **holds position** and writes a critical routing log rather
  than teleporting or failing silently.

Please still run `npm run dev` once and click through — the above covers logic
and module wiring, not pixel layout.
